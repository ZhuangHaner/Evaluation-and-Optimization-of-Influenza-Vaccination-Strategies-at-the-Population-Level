close all; clear; clc;

n = 5;  % number of subgroups 
load('VaccinationTable.mat')
load('processedTable.mat');
params.tSpan = [0, 114] + 0.5;
params.k  = 0.50;
params.omega  = 0.53;
params.omega1  = 0.83;
params.p = 0.667;
params.gamma  = 0.31;
params.gamma1  = 0.25;
params.f = 0.1;
params.n = 5;

% 疫苗效果参数
params.VEI = 0.4; % 20-40
params.VES = 0.4; % 30-40
params.VEP = 0.67; % 14-67 

% 2023-10-22(1373),2023-12-19(1431),2024-02-13(1487) T

E0 = T{1372,2:6}'/params.p / params.omega * (1 - params.VES);
I0 = T{1373,2:6}' * (1 - params.VES);
A0 = [0, 0, 0, 0, 0]';
R0 = [0, 0, 0, 0, 0]';
pre27VacNum = sum(VT{1300:1337-1 - 1/params.f, 2:6})';
pre10VacNum = sum(VT{1337-1/params.f:1336, 2:6})';
% 1300:1450 ,2023-9-15,2024-2-13 VT
% 1337 ,    2023-10-22
population = [103.26, 129.98, 72.28, 1413.68, 465.1]' * 1e4;
totalVacNum = sum(VT{1300:1450, 2:6})';
totalVacRate = totalVacNum ./ population;
epiVacNum = totalVacNum - pre27VacNum - pre10VacNum * 0.5;
day = days(VT.Date(1450) - VT.Date(1337)) + 1 ;
params.fai = epiVacNum / day ./ population;

Sv0 = pre27VacNum  + pre10VacNum * 0.5;
Ev0 = T{1372,2:6}'/params.p / params.omega * params.VES;
Iv0 = T{1373,2:6}'* params.VES;
Av0 = [0, 0, 0, 0, 0]';
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;

params.initialStates = [S0; E0; I0; A0; R0; Sv0; Ev0; Iv0; Av0];

%% 拟合效果图
ageGroups = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};
timeActual = datetime(2023,10,22) + caldays(0:(1487-1373));

colors = ["#C2ABC8", "#902525", "#F2BB6B", "#DE7833", "#7082C8"];

fig = figure;
fig.Position = [248.2,291.4,1374.4,584];
tiledlayout(1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

nexttile;
hActual = plot(timeActual, T{1373:1487, 2:6});
hold on;

for i = 1:length(hActual)
    set(hActual(i), 'LineWidth', 1.5, 'Color', colors(i)); 
end

xlim([datetime(2023,10,22) datetime(2024,2,13)]);
datetick('x', 'yyyy-mm-dd', 'keeplimits');
xlabel('Date');
ylabel('New Cases');

ylim([0, max(ylim) * 1.1]);

yticks1 = get(gca, 'YTick'); 
yticklabels1 = strcat(string(yticks1/1000), 'k');
set(gca, 'YTickLabel', yticklabels1);

xline(datetime(2023,12,19), '--k', '2023-12-19', 'LabelVerticalAlignment', 'top', 'LabelHorizontalAlignment', 'center');
text(datetime(2023,11,30), max(ylim) * 0.9, 'Segment1', 'HorizontalAlignment', 'center');
text(datetime(2024,1,1), max(ylim) * 0.9, 'Segment2', 'HorizontalAlignment', 'center');

A1 = readmatrix('estimatedA.xlsx');
A2 = readmatrix('estimatedA2.xlsx');
B1 = readmatrix('estimatedB.xlsx');
B2 = readmatrix('estimatedB2.xlsx');

dxdt = @(t,x) computeDerivative(A1, B1, A2, B2, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
yPredicted = params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n); % omega * E

timePredicted = datetime(2023,10,22) + days(tt - tt(1));

hFitted = plot(timePredicted, yPredicted, '--');

for i = 1:length(hActual)
    set(hFitted(i), 'Color', colors(i), 'LineWidth', 1.5);
end

legendLabels = [strcat(ageGroups, ' (Actual)'), strcat(ageGroups, ' (Fitted)')];
legend([hActual; hFitted], legendLabels, 'Location', 'northeast');

text(datetime(2023,10,23), max(ylim) * 0.95, 'A', 'FontSize', 14, 'FontWeight', 'bold');


R2_values = zeros(1, 5); 

for i = 1:length(hActual)

    alignedFitted = interp1(timePredicted, yPredicted(:, i), timeActual, 'linear', 'extrap');

    actualValues = T{1373:1487, i + 1}; 
    ResidualSumSquares = sum((actualValues - alignedFitted').^2);
    TotalSumSquares = sum((actualValues - mean(actualValues)).^2);
    R2_values(i) = 1 - ResidualSumSquares / TotalSumSquares;

end

text(datetime(2024,02,01), max(T{1373:1487, 5}) * 0.67, ...
    sprintf('R^2 = %.2f', R2_values(1)), ...
    'Color', colors(1), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

text(datetime(2024,02,01), max(T{1373:1487, 5}) * 0.62, ...
    sprintf('R^2 = %.2f', R2_values(2)), ...
    'Color', colors(2), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

text(datetime(2024,02,01), max(T{1373:1487, 5}) * 0.57, ...
    sprintf('R^2 = %.2f', R2_values(3)), ...
    'Color', colors(3), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

text(datetime(2024,02,01), max(T{1373:1487, 5}) * 0.72, ...
    sprintf('R^2 = %.2f', R2_values(4)), ...
    'Color', colors(4), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

text(datetime(2024,02,01), max(T{1373:1487, 5}) * 0.52, ...
    sprintf('R^2 = %.2f', R2_values(5)), ...
    'Color', colors(5), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');



totalT = sum(T{1373:1487, 2:6}, 2);
totalyPredicted = sum(yPredicted, 2);

nexttile;
hTotalActual = plot(timeActual, totalT, 'Color', [0.349, 0.612, 0.749], 'LineWidth', 1.5);
hold on;

hTotalFitted = plot(timePredicted, totalyPredicted, 'Color', [0.761, 0.341, 0.349], 'LineStyle', '--', 'LineWidth', 1.5);

xlim([datetime(2023,10,22) datetime(2024,2,13)]);
datetick('x', 'yyyy-mm-dd', 'keeplimits');
xlabel('Date');

yticks2 = [0 2000 4000 6000 8000 10000 12000 14000 16000];
yticklabels2 = strcat(string(yticks2/1000), 'k');
set(gca, 'YTick', yticks2, 'YTickLabel', yticklabels2);

xline(datetime(2023,12,19), '--k', '2023-12-19', 'LabelVerticalAlignment', 'top', 'LabelHorizontalAlignment', 'center');
text(datetime(2023,11,20), max(ylim) * 0.9, 'Segment1', 'HorizontalAlignment', 'center');
text(datetime(2024,1,1), max(ylim) * 0.9, 'Segment2', 'HorizontalAlignment', 'center');

legend([hTotalActual, hTotalFitted], {'Actual Daily Cases', 'Fitted Daily Cases'}, 'Location', 'northeast');
text(datetime(2023,10,23), max(ylim) * 0.95, 'B', 'FontSize', 14, 'FontWeight', 'bold');


AlignedYPredicted = interp1(timePredicted, yPredicted, timeActual, 'linear');

TotalActualCases = sum(T{1373:1487, 2:6}, 2);
TotalPredictedCases = sum(AlignedYPredicted, 2);
ResidualSumSquares = sum((TotalActualCases - TotalPredictedCases).^2);
TotalSumSquares = sum((TotalActualCases - mean(TotalActualCases)).^2);
TotalRSquared = 1 - ResidualSumSquares / TotalSumSquares;

text(datetime(2024,1,25), max(ylim) * 0.85, sprintf('R^2 = %.2f', TotalRSquared), ...
    'FontSize', 12, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');


% exportgraphics(gcf, '../../Figures/Comparison of Daily Cases (Actual vs Fitted).tif', 'Resolution', 300);
% exportgraphics(gcf, '../../Figures/Comparison of Daily Cases (Actual vs Fitted).pdf', 'Resolution', 300);

%% 拟合的振幅图

% close all; clear; clc;
n = 5;
A1 = readmatrix('estimatedA.xlsx');
A2 = readmatrix('estimatedA2.xlsx');
B1 = readmatrix('estimatedB.xlsx');
B2 = readmatrix('estimatedB2.xlsx');

customColorsPositiveLimited = interp1(linspace(0, 1, 3), ...
    [234/255, 255/255, 246/255; 152/255, 202/255, 221/255; 97/255, 170/255, 207/255], linspace(0, 1, 256));

customColorsNegativePositive = interp1(linspace(0, 1, 6), [
    218/255, 149/255, 153/255; 
    233/255, 198/255, 198/255; 
    249/255, 239/255, 239/255;  
    234/255, 255/255, 246/255;  
    152/255, 202/255, 221/255;  
    97/255, 170/255, 207/255    
], linspace(0, 1, 256));

fig = figure('Position', [100, 50, 1200, 1000]);

tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');


fontSize = 10;      
labelFontSize = 14; 
axisFontSize = 12;  


nexttile;
imagesc(round(A1, 2));  
colormap(gca, customColorsPositiveLimited);
h = colorbar('FontSize', axisFontSize);
h.Ticks = linspace(0, max(A1(:)), 5); 
h.TickLabels = cellstr(num2str(h.Ticks', '%.1f'));
clim([0, max(A1(:))]); 
text(0.7, 0.5, 'A', 'FontSize', labelFontSize, 'FontWeight', 'bold', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
title('Amplitude of the First Segment of Fitting', 'FontSize', fontSize, 'FontWeight', 'normal');
axis on;
set(gca, 'FontSize', axisFontSize, 'XTick', []); 
set(gca, 'FontSize', axisFontSize, 'YTick', 1:n); 
yticklabels({'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'});

textStrings = num2str(A1(:), '%.2f'); 
textStrings = strtrim(cellstr(textStrings));
[x, y] = meshgrid(1:size(A1, 2), 1:size(A1, 1));
text(x(:), y(:), textStrings, 'HorizontalAlignment', 'center', 'FontSize', axisFontSize - 1, 'Color', [0 0 0 0.6]);


nexttile;
imagesc(round(B1, 2)); 
colormap(gca, customColorsNegativePositive); 
h = colorbar('FontSize', axisFontSize);
h.Ticks = pi * (-2:1:2); 
h.TickLabels = {'-2π', '-π', '0', 'π', '2π'}; 
clim([min(B1(:)), max(B1(:))]);
text(0.7, 0.5, 'B', 'FontSize', labelFontSize, 'FontWeight', 'bold', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
title('Phase of the First Segment of Fitting', 'FontSize', fontSize, 'FontWeight', 'normal');
axis on;
set(gca, 'FontSize', axisFontSize, 'XTick', [], 'YTick', []);

textStrings = strcat(num2str(round(B1(:) / pi, 2), '%.2f'), 'π');
textStrings = strtrim(cellstr(textStrings));
text(x(:), y(:), textStrings, 'HorizontalAlignment', 'center', 'FontSize', axisFontSize - 1); 

nexttile;
imagesc(round(A2, 2));
colormap(gca, customColorsPositiveLimited);
h = colorbar('FontSize', axisFontSize);
h.Ticks = linspace(0, max(A2(:)), 5); 
h.TickLabels = cellstr(num2str(h.Ticks', '%.1f'));
clim([0, max(A2(:))]);
text(0.7, 0.5, 'C', 'FontSize', labelFontSize, 'FontWeight', 'bold', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
title('Amplitude of the Second Segment of Fitting', 'FontSize', fontSize, 'FontWeight', 'normal');
axis on;
set(gca, 'FontSize', axisFontSize);
set(gca, 'FontSize', axisFontSize, 'XTick', 1:n); 
set(gca, 'FontSize', axisFontSize, 'YTick', 1:n); 
yticklabels({'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'}); 
xticklabels({'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'}); 
textStrings = num2str(A2(:), '%.2f');
textStrings = strtrim(cellstr(textStrings));
text(x(:), y(:), textStrings, 'HorizontalAlignment', 'center', 'FontSize', axisFontSize, 'Color', [0 0 0 0.6]); 


nexttile;
imagesc(round(B2, 2)); 
colormap(gca, customColorsNegativePositive); 
h = colorbar('FontSize', axisFontSize);
h.Ticks = pi * (-2:1:2); 
h.TickLabels = {'-2π', '-π', '0', 'π', '2π'}; 
clim([min(B2(:)), max(B2(:))]);
text(0.7, 0.5, 'D', 'FontSize', labelFontSize, 'FontWeight', 'bold', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
title('Phase of the Second Segment of Fitting', 'FontSize', fontSize, 'FontWeight', 'normal');
axis on;
set(gca, 'FontSize', axisFontSize, 'YTick', []); 
set(gca, 'FontSize', axisFontSize, 'XTick', 1:n); 
xticklabels({'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'});

textStrings = strcat(num2str(round(B2(:) / pi, 2), '%.2f'), 'π'); 
textStrings = strtrim(cellstr(textStrings));
text(x(:), y(:), textStrings, 'HorizontalAlignment', 'center', 'FontSize', axisFontSize - 1);

% exportgraphics(fig, ['../Figures/' 'Fitted Amplitude and Phase Across Two Segments.tif'], 'Resolution', 300, 'ContentType', 'vector');
% exportgraphics(gcf, '../../Figures/Fitted Amplitude and Phase Across Two Segments.png', 'Resolution', 300);


%% 总防控效果图 2023冬季

n = 5;  % number of subgroups 
load('VaccinationTable.mat')
load('processedTable.mat');
params.tSpan = [0, 114] + 0.5;
params.k  = 0.50;
params.omega  = 0.53;
params.omega1  = 0.83;
params.p = 0.667;
params.gamma  = 0.31;
params.gamma1  = 0.25;
params.f = 0.1;
params.n = 5;

% 疫苗效果参数
params.VEI = 0.4; % 20-40
params.VES = 0.4; % 30-40
params.VEP = 0.67; % 14-67 

% 2023-10-22(1373),2023-12-19(1431),2024-02-13(1487) T

E0 = T{1372,2:6}'/params.p / params.omega * (1 - params.VES);
I0 = T{1373,2:6}' * (1 - params.VES);
A0 = [0, 0, 0, 0, 0]';
R0 = [0, 0, 0, 0, 0]';
pre27VacNum = sum(VT{1300:1337-1 - 1/params.f, 2:6})';
pre10VacNum = sum(VT{1337-1/params.f:1336, 2:6})';
% 1300:1450 ,2023-9-15,2024-2-13 VT
% 1337 ,    2023-10-22
population = [103.26, 129.98, 72.28, 1413.68, 465.1]' * 1e4;
totalVacNum = sum(VT{1300:1450, 2:6})';
totalVacRate = totalVacNum ./ population;
popuVacRate = sum(totalVacNum) / sum(population);
epiVacNum = totalVacNum - pre27VacNum - pre10VacNum * 0.5;
day = days(VT.Date(1450) - VT.Date(1337)) + 1 ;
params.fai = epiVacNum / day ./ population;

Sv0 = pre27VacNum  + pre10VacNum * 0.5;
Ev0 = T{1372,2:6}'/params.p / params.omega * params.VES;
Iv0 = T{1373,2:6}'* params.VES;
Av0 = [0, 0, 0, 0, 0]';
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;

params.initialStates = [S0; E0; I0; A0; R0; Sv0; Ev0; Iv0; Av0];

A1 = readmatrix('estimatedA.xlsx');
A2 = readmatrix('estimatedA2.xlsx');
B1 = readmatrix('estimatedB.xlsx');
B2 = readmatrix('estimatedB2.xlsx');

%%%%%%%%%%%
initialTotalVacNum = sum(totalVacNum);
ageGroups = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};
timeRange = T.Date(1373):T.Date(1487);
timeDays = linspace(0.5, length(timeRange) - 0.5, length(timeRange));

figure('Position', [100, 50, 1200, 1000])

%%%%%%%%%%%%%%%%%%%%%%%%%%%   实际情况
dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

casesPredicted = sum(params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n), 2) / 1000;

casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
plot(timeRange, casesPredictedInterp, 'LineWidth', 1,'Color','k', ...
    'DisplayName','Actual Epidemic');

hold on


%%%%%%%%%%%%%%%%%%%%%%  模拟无干预状态
vacRateFactor = [0.0163; 0.0242; 0.0499];

pre27VacNumAdjusted = pre27VacNum;
pre10VacNumAdjusted = pre10VacNum;
adjustedTotalVacNum = totalVacNum;

pre27VacNumAdjusted([2, 3, 5]) = pre27VacNum([2, 3, 5]) .* vacRateFactor;
pre10VacNumAdjusted([2, 3, 5]) = pre10VacNum([2, 3, 5]) .* vacRateFactor;
adjustedTotalVacNum([2, 3, 5]) = totalVacNum([2, 3, 5]) .* vacRateFactor;

epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;
params.fai = epiVacNumAdjusted / day ./ population;

Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;

dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

casesPredicted = sum(params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n), 2) / 1000;
casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
% plot(timeRange, casesPredictedInterp, 'LineWidth', 1,'LineStyle','--');
% plot(timeRange, casesPredictedInterp, 'LineWidth', 1,'LineStyle','--', ...
%     'DisplayName', ['SVR = ' num2str(0.01 * 100, '%.0f') '%']);
plot(timeRange, casesPredictedInterp, 'LineWidth', 1.3,'LineStyle','--', 'color','r', ...
    'DisplayName', 'Without Strategy');

%%%%%%%%%%%%%%%%%%%%    模拟提高疫苗接种速率
SpeedFactorIdx = 1.50;

pre27VacNumAdjusted = pre27VacNum * SpeedFactorIdx;
pre10VacNumAdjusted = pre10VacNum * SpeedFactorIdx;

epiVacNumAdjusted = totalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;
params.fai = epiVacNumAdjusted / day ./ population;

Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;

dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
casesPredicted = sum(params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n), 2) / 1000;
casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');

plot(timeRange, casesPredictedInterp, 'LineWidth', 1, 'LineStyle','-.', 'color','b', ...
    'DisplayName', ['Speed = ' num2str(SpeedFactorIdx) ' times']);

%%%%%%%%%%%%%%%%%%%%%   模拟提前3周疫苗接种

timeShift = 3;
pre27VacNumShifted = sum(VT{1300 : 1337 - 1 - 1/params.f + timeShift*7 , 2:6})';
pre10VacNumShifted = sum(VT{1337 - 1/params.f + timeShift*7: 1336 + timeShift*7, 2:6})';

Sv0 = pre27VacNumShifted  + pre10VacNumShifted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;

totalVacNumShifted = sum(VT{1300:1450 + timeShift*7, 2:6})';

epiVacNumShifted = totalVacNumShifted - pre27VacNumShifted - pre10VacNumShifted * 0.5;
params.fai = epiVacNumShifted / day ./ population;

dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
casesPredicted = sum(params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n), 2) / 1000;
casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');

plot(timeRange, casesPredictedInterp, 'LineWidth', 1,'color',[0 0.6 0],  ...
    'DisplayName', ['Shift = ' num2str(timeShift) ' weeks']);



legend show
xlim([timeRange(1), timeRange(end)]);
drawnow;
xtickformat('yyyy-MM');

title('2023 Winter Influenza Epidemic')
yticks = get(gca, 'YTick');
yticklabels = arrayfun(@(y) sprintf('%dk', y), yticks, 'UniformOutput', false);
set(gca, 'YTickLabel', yticklabels);
ylabel('Daily Cases','FontSize',10)
xlabel('Date','FontSize',10)

exportgraphics(gcf, '../../Figures/总防控效果对比图.pdf', 'Resolution', 300);

