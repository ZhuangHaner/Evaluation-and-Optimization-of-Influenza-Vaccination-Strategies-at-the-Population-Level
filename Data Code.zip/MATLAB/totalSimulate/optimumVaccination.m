close all; clear; clc;

n = 5;  % number of subgroups 
load('VaccinationTable.mat')
load('processedTable.mat');
params.tSpan = [0, 114] + 0.5;
params.k  = 0.50;
params.omega  = 0.53;
params.omega1  = 0.83;
params.p = 0.667;
params.gamma  = 0.31;
params.gamma1  = 0.25;
params.f = 0.1;
params.n = 5;

% 疫苗效果参数
params.VEI = 0.4; % 20-40
params.VES = 0.4; % 30-40
params.VEP = 0.67; % 14-67 


% 2023-10-22(1373),2023-12-19(1431),2024-02-13(1487) T

E0 = T{1372,2:6}'/params.p / params.omega * (1 - params.VES);
I0 = T{1373,2:6}' * (1 - params.VES);
A0 = [0, 0, 0, 0, 0]';
R0 = [0, 0, 0, 0, 0]';
pre27VacNum = sum(VT{1300:1337-1 - 1/params.f, 2:6})';
pre10VacNum = sum(VT{1337-1/params.f:1336, 2:6})';
% 1300:1450 ,2023-9-15,2024-2-13 VT
% 1337 ,    2023-10-22
population = [103.26, 129.98, 72.28, 1413.68, 465.1]' * 1e4;
totalVacNum = sum(VT{1300:1450, 2:6})';
totalVacRate = totalVacNum ./ population;
popuVacRate = sum(totalVacNum) / sum(population);
epiVacNum = totalVacNum - pre27VacNum - pre10VacNum * 0.5;
day = days(VT.Date(1450) - VT.Date(1337)) + 1 ;
params.fai = epiVacNum / day ./ population;

Sv0 = pre27VacNum  + pre10VacNum * 0.5;
Ev0 = T{1372,2:6}'/params.p / params.omega * params.VES;
Iv0 = T{1373,2:6}'* params.VES;
Av0 = [0, 0, 0, 0, 0]';
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates = [S0; E0; I0; A0; R0; Sv0; Ev0; Iv0; Av0];

A1 = readmatrix('estimatedA.xlsx');
A2 = readmatrix('estimatedA2.xlsx');
B1 = readmatrix('estimatedB.xlsx');
B2 = readmatrix('estimatedB2.xlsx');


%%
%   M 是1百万
resultTable = cell2table(cell(0, 12), ...
    'VariableNames', {'AgeGroup', 'VaccineCoverage', 'PeakCases', 'TotalInfections', ...
                      'Hospitalizations', 'Deaths', 'MedicalCost(M)', ...
                      'VaccineCost(M)', 'HICER', 'DICER',  'DMCICER', 'CIICER'});

% 柱状图表格 CIR:cumulative infection rate。  RRR：Relative Risk Reduction
barTable = cell2table(cell(0, 9), ...
    'VariableNames', {'AgeGroup', 'VR', 'age0-5', 'age6-12', 'age13-18', ...
                      'age19-59', 'age60+', 'CIR', 'RRR'});

eco.agegroup = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};
eco.HospRate = [313, 76, 2, 7, 53]/1e5;
eco.HospRateForIV = eco.HospRate * 0.5; %
eco.HospCI = [[280, 349]; [61, 95]; [0, 8]; [3, 14]; [41 70]]/1e5;
eco.HospCIForIV = eco.HospCI * 0.5; %
eco.DeathRate = [0, 0, 0, 0.002, 0.015];
eco.DeathRateForIV = eco.DeathRate * 0.5; %
eco.DeathCI = [[0, 0.0001]; [0, 0.0001]; [0, 0.0001]; [0.001, 0.003]; [0.005, 0.015]];
eco.DeathCIForIV = eco.DeathCI * 0.5; %
eco.MedCost = [231, 231, 231, 854, 1776.7];
eco.MedCostForIV = eco.MedCost * 0.5; %
eco.MedCostCI = [[149, 313]; [149, 313]; [149, 313];  [409, 1299]; [1234.6, 2318.8]];
eco.MedCostCIForIV = eco.MedCostCI * 0.5; %
eco.VaccineCost = [23.74, 23.74, 23.74, 23.74, 23.74];
eco.VaccineCostCI = [[17.48, 30]; [17.48, 30]; [17.48, 30]; [17.48, 30]; [17.48, 30]];
eco.OutCost = [61.6, 22.8, 22.8, 22.8, 31];
eco.OutCostForIV = eco.OutCost * 0.5; %
eco.OutCostCI = [[56, 67.1]; [20.9, 24.8]; [20.9, 24.8]; [20.9, 24.8]; [11, 64]];
eco.OutCostCIForIV = eco.OutCostCI * 0.5; %

adjustedVacRates = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.75, 0.8];
initialVacRate = totalVacRate;

colors = [
    0, 18, 25;
    0, 96, 115;
    9, 147, 150;
    145, 211, 192;
    235, 215, 165;
    238, 155, 0;
    204, 102, 2;
    188, 62, 3;
    174, 32, 18;   
    155, 34, 39
] / 255;

fig = figure;
set(fig, 'Units', 'normalized', 'OuterPosition', [0 0 1 1]);

tiledlayout(2, 4, 'TileSpacing', 'Compact');

ageGroups = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};

timeRange = T.Date(1373):T.Date(1487);  
timeDays = linspace(0.5, length(timeRange) - 0.5, length(timeRange)); 
optimumType = 1;

for ageIdx = 1:n
    nexttile;
    hold on;

    adjustedTotalVacNum = totalVacNum;
    params.fai = epiVacNum / day ./ population;
    
    pre27VacNumAdjusted = pre27VacNum;
    pre10VacNumAdjusted = pre10VacNum;

    Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
    S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
    params.initialStates(1:n) = S0;
    params.initialStates(5*n+1:6*n) = Sv0;

    dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
    [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

    casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
    casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
%%% 
    yPredicted = params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n); 
    yPredictedForI = params.p * params.omega * xPredicted(:, n+1:2*n);
    yPredictedForIV = params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n);
    yAgePredictedForI = trapz(tt, yPredictedForI);
    yAgePredictedForIV = trapz(tt, yPredictedForIV);
    
    avr.HospNumber = sum(yAgePredictedForI .* eco.HospRate + yAgePredictedForIV .* eco.HospRateForIV);
    avr.DeathNumber = sum(yAgePredictedForI .* eco.DeathRate + yAgePredictedForIV .* eco.DeathRateForIV);
    avr.Infections = sum(yAgePredictedForI + yAgePredictedForIV);
    avr.MediCost = sum(yAgePredictedForI .* eco.HospRate .* eco.MedCost + ...
    yAgePredictedForI .* (1 - eco.HospRate) .* eco.OutCost + ...
    yAgePredictedForIV .* eco.HospRateForIV .* eco.MedCostForIV + ...
    yAgePredictedForIV .* (1 - eco.HospRateForIV) .* eco.OutCostForIV);
    avr.VacNumber = sum(totalVacNum);
    avr.VacCost = sum(totalVacNum' .* eco.VaccineCost);

    avr.MediCostCi = [15.7855   20.8697]*1e6; %%%%%% 改参数需要更新
    avr.HospNumberCi = [352.0865  503.6142]; 
    avr.DeathNumberCi = [0.5237    1.5957]*1e3; 
%%%
    [resultTable, barTable] = updateResultTable(resultTable, ageIdx, totalVacRate(ageIdx), ...
                                    adjustedTotalVacNum, ...
                                    casesPredictedInterp, population, ...
                                    eco, params, avr, optimumType, xPredicted, tt, barTable);
%%%
    plot(timeRange, casesPredictedInterp, 'LineWidth', 1.5, 'DisplayName', ...
         ['VR = ' num2str(round(initialVacRate(ageIdx) * 100, 2)) '%'], ...
         'Color', colors(1, :));
    drawnow;
    vacRateAdjustments = adjustedVacRates(adjustedVacRates > initialVacRate(ageIdx));
    adjustedColors = [];
    title(ageGroups{ageIdx})
    switch ageIdx
        case 2
            adjustedColors = colors([4, 7, 10], :);
        case 3
            adjustedColors = colors([2, 4, 6, 8, 10], :);
    end

    for i = 1:length(vacRateAdjustments)
        vacRateAdjusted = vacRateAdjustments(i);
        currentVacFactor = vacRateAdjusted / initialVacRate(ageIdx);
        pre27VacNumAdjusted(ageIdx) = pre27VacNum(ageIdx) * currentVacFactor;
        pre10VacNumAdjusted(ageIdx) = pre10VacNum(ageIdx) * currentVacFactor;

        adjustedTotalVacNum(ageIdx) = totalVacNum(ageIdx) * currentVacFactor;
        epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;
        params.fai = epiVacNumAdjusted / day ./ population;

        Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
        S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
        params.initialStates(1:n) = S0;
        params.initialStates(5*n+1:6*n) = Sv0;

        dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
        [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

        casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
        casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
        [resultTable, barTable] = updateResultTable(resultTable, ageIdx, vacRateAdjusted, ...
                                        adjustedTotalVacNum, ...
                                        casesPredictedInterp, population, ...
                                        eco, params, avr, optimumType, xPredicted, tt, barTable);

        if ageIdx == 2
            if i <= size(adjustedColors, 1)
                colorToUse = adjustedColors(i, :);  
            else
                colorToUse = colors(mod(i, size(colors,1)) +1, :); 
            end
        elseif ageIdx == 3
            if i <= size(adjustedColors, 1)
                colorToUse = adjustedColors(i, :); 
            else
                colorToUse = colors(mod(i, size(colors,1)) +1, :); 
            end
        else
            colorToUse = colors(mod(i, size(colors,1)) +1, :);
        end

        plot(timeRange, casesPredictedInterp, 'LineWidth', 1, 'DisplayName', ...
             ['VR = ' num2str(round(vacRateAdjusted * 100, 2)) '%'], ...
             'Color', colorToUse);
        drawnow;
    end

    hold off;

    if ismember(ageIdx, [1, 5])
        ylabel('Infectious population','FontSize',8);
    end
    if ismember(ageIdx, [4, 5])
        xlabel('Date','FontSize',8);
    end

    xlim([timeRange(1), timeRange(end)]);
    xtickformat('yyyy-MM');

    yticks = get(gca, 'YTick');
    yticklabels = arrayfun(@(y) sprintf('%dk', y), yticks, 'UniformOutput', false);
    set(gca, 'YTickLabel', yticklabels);


    lgd = legend('show', 'NumColumns', 1,'Box','off');
    lgd.FontSize = 6;
    legend show          

    % annotation('textbox', [annotationPositions(ageIdx, 1), annotationPositions(ageIdx, 2), 0.05, 0.05], ...
    %            'String', letters(ageIdx), 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
end

nexttile;
optimumType = 2;
timeShifts = 1:9;
adjustedTotalVacNum = totalVacNum;
params.fai = epiVacNum / day ./ population;

pre27VacNumAdjusted = pre27VacNum;
pre10VacNumAdjusted = pre10VacNum;

Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;


dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
[resultTable, barTable] = updateResultTable(resultTable, 0, popuVacRate, ...
                                sum(adjustedTotalVacNum),  ...
                                casesPredictedInterp, population, ...
                                eco, params, avr, optimumType, xPredicted, tt, barTable);

plot(timeRange, casesPredictedInterp, 'LineWidth', 1.5, 'DisplayName', ...
    'Initial Strategy', 'Color', colors(1, :));
hold on;
title('Earlier Vaccination Timing')
for shiftIdx = 1:length(timeShifts)
    timeShift = timeShifts(shiftIdx);
        
    pre27VacNumShifted = sum(VT{1300 : 1337 - 1 - 1/params.f + timeShift*7 , 2:6})';
    pre10VacNumShifted = sum(VT{1337 - 1/params.f + timeShift*7: 1336 + timeShift*7, 2:6})';
    
    Sv0 = pre27VacNumShifted  + pre10VacNumShifted * 0.5;
    S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
    params.initialStates(1:n) = S0;
    params.initialStates(5*n+1:6*n) = Sv0;

    totalVacNumShifted = sum(VT{1300:1450 + timeShift*7, 2:6})';

    epiVacNumShifted = totalVacNumShifted - pre27VacNumShifted - pre10VacNumShifted * 0.5;
    params.fai = epiVacNumShifted / day ./ population;

    dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
    [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
    casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
    casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
    [resultTable, barTable] = updateResultTable(resultTable, shiftIdx, popuVacRate, ...
                                    sum(adjustedTotalVacNum), ...
                                    casesPredictedInterp, population, ...
                                    eco, params, avr, optimumType, xPredicted, tt, barTable);
    
    plot(timeRange, casesPredictedInterp, 'LineWidth', 1, ...
         'DisplayName', ['Shift = ' num2str(timeShift) ' weeks'], ...
         'Color', colors(shiftIdx + 1, :));
end

% ylabel('Infectious population','FontSize',8);
xlabel('Date','FontSize',8);
xtickformat('yyyy-MM');
legend('Location', 'northeast', 'NumColumns', 1, 'FontSize',6,'Box','off'); 

yticks = get(gca, 'YTick');
yticklabels = arrayfun(@(y) sprintf('%dk', y), yticks, 'UniformOutput', false);
set(gca, 'YTickLabel', yticklabels);
xlim([timeRange(1), timeRange(end)]);
hold off;

%%%%%%%%%%%%%%%%%%%%% 增加接种速率子图
nexttile;
optimumType = 3;

% totalVacNum./(pre27VacNum+pre10VacNum*0.5) % 检测速率的最低值，
SpeedFactor = linspace(1.0625,1.5,8);
adjustedTotalVacNum = totalVacNum;
params.fai = epiVacNum / day ./ population;

pre27VacNumAdjusted = pre27VacNum;
pre10VacNumAdjusted = pre10VacNum;

Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;

dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
[resultTable, barTable] = updateResultTable(resultTable, 1, popuVacRate, ...
                                sum(adjustedTotalVacNum),  ...
                                casesPredictedInterp, population, ...
                                eco, params, avr, optimumType, xPredicted, tt, barTable);

plot(timeRange, casesPredictedInterp, 'LineWidth', 1.5, 'DisplayName', ...
    'Initial Strategy', 'Color', colors(1, :));
hold on;
title('Accelerated Vaccination Rate')

for i = 1:length(SpeedFactor)
    SpeedFactorIdx = SpeedFactor(i);
        
    % vacRateAdjusted = vacRateAdjustments(i);
    % currentVacFactor = vacRateAdjusted / initialVacRate(ageIdx);
    pre27VacNumAdjusted = pre27VacNum * SpeedFactorIdx;
    pre10VacNumAdjusted = pre10VacNum * SpeedFactorIdx;

    % adjustedTotalVacNum(ageIdx) = totalVacNum(ageIdx) * currentVacFactor;
    epiVacNumAdjusted = totalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;
    params.fai = epiVacNumAdjusted / day ./ population;

    Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
    S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
    params.initialStates(1:n) = S0;
    params.initialStates(5*n+1:6*n) = Sv0;

    % totalVacNumShifted = sum(VT{1300:1450 + SpeedFactorIdx*7, 2:6})';

    % epiVacNumShifted = totalVacNumShifted - pre27VacNumShifted - pre10VacNumShifted * 0.5;
    % params.fai = epiVacNumShifted / day ./ population;

    dxdt = @(t, x) computeDerivative(A1, B1, A2, B2, params, t, x);
    [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
    casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
    casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
    [resultTable, barTable] = updateResultTable(resultTable, SpeedFactorIdx, popuVacRate, ...
                                    sum(adjustedTotalVacNum), ...
                                    casesPredictedInterp, population, ...
                                    eco, params, avr, optimumType, xPredicted, tt, barTable);
    
    plot(timeRange, casesPredictedInterp, 'LineWidth', 1, ...
         'DisplayName', ['Speed = ' num2str(SpeedFactorIdx) ' times'], ...
         'Color', colors(i + 1, :));
end

% ylabel('Infectious population','FontSize',8);
xlabel('Date','FontSize',8);
xtickformat('yyyy-MM');
legend('Location', 'northeast', 'NumColumns', 1, 'FontSize',6,'Box','off'); 

yticks = get(gca, 'YTick');
yticklabels = arrayfun(@(y) sprintf('%dk', y), yticks, 'UniformOutput', false);
set(gca, 'YTickLabel', yticklabels);
xlim([timeRange(1), timeRange(end)]);
hold off;

annotation('textbox', [0.07, 0.88, 0.05, 0.05], 'String', 'A', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.29, 0.88, 0.05, 0.05], 'String', 'B', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.51, 0.88, 0.05, 0.05], 'String', 'C', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.74, 0.88, 0.05, 0.05], 'String', 'D', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.07, 0.43, 0.05, 0.05], 'String', 'E', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.29, 0.43, 0.05, 0.05], 'String', 'F', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.51, 0.43, 0.05, 0.05], 'String', 'G', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');

% exportgraphics(gcf, ['../../Figures/' ...
%     'Optimization of vaccination.pdf'], 'Resolution', 300);


%%
function [resultTable, barTable]= updateResultTable(resultTable, ageIdx, vacRateAdjusted, ...
                                         adjustedTotalVacNum,  ...
                                         casesPredicted, population, ...
                                         eco, params, avr, optimumType, xPredicted, tt, barTable)
    n = params.n;

    hospRate = eco.HospRate; 
    hospCi = eco.HospCI;     
    deathRate = eco.DeathRate;
    deathCi = eco.DeathCI;    
    medCost = eco.MedCost;   
    medCostCi = eco.MedCostCI;
    vaccineCost = eco.VaccineCost;
    vaccineCostCi = eco.VaccineCostCI;
    outCost = eco.OutCost;
    outCostCi = eco.OutCostCI;

    hospRateIV = eco.HospRateForIV; 
    hospCiIV = eco.HospCIForIV;     
    deathRateIV = eco.DeathRateForIV;
    deathCiIV = eco.DeathCIForIV;    
    medCostIV = eco.MedCostForIV;   
    medCostCiIV = eco.MedCostCIForIV;
    outCostIV = eco.OutCostForIV; 
    outCostCiIV = eco.OutCostCIForIV;

    % 第2列
    if optimumType == 1
    vaccineCount = adjustedTotalVacNum(ageIdx);
    vaccineCoverage = sprintf('%.2f%%', vacRateAdjusted * 100);
    % elseif optimumType == 2
    % vaccineCount = adjustedTotalVacNum;
    % vaccineCoverage = sprintf('%.2f%%', vacRateAdjusted * 100);
    else 
    vaccineCount = adjustedTotalVacNum;
    vaccineCoverage = sprintf('%.2f%%', vacRateAdjusted * 100);
    end
    % 第3列
    peakCases = max(casesPredicted) * 1000;
    peakCasesPercent = sprintf('%.2f‰', (peakCases / sum(population)) * 1000);

    % 第4列
    yPredictedForI = params.p * params.omega * xPredicted(:, n+1:2*n);
    yPredictedForIV = params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n);
    yAgePredictedForI = trapz(tt, yPredictedForI); 
    yAgePredictedForIV = trapz(tt, yPredictedForIV); 
    ageInfection = yAgePredictedForI + yAgePredictedForIV;
    totalInfections = sum(ageInfection); 
    CIR = totalInfections / sum(population);
    totalInfectionsPercent = sprintf('%.2f%%', (totalInfections / sum(population)) * 100);

    % 第5列
    hospCountsI = yAgePredictedForI .* hospRate; 
    hospCountsIV = yAgePredictedForIV .* hospRateIV; 
    totalHospCounts = sum(hospCountsI + hospCountsIV);
    hospCiTotal = sum(yAgePredictedForI' .* hospCi + yAgePredictedForIV' .* hospCiIV, 1); 
    hospRange = sprintf('[%.0f, %.0f]', hospCiTotal(1), hospCiTotal(2));

    % 第6列
    deathCountsI = yAgePredictedForI .* deathRate; 
    deathCountsIV = yAgePredictedForIV .* deathRateIV;
    totalDeathCounts = sum(deathCountsI + deathCountsIV);
    deathCiTotal = sum(yAgePredictedForI' .* deathCi + yAgePredictedForIV' .* deathCiIV, 1); 
    deathRange = sprintf('[%.0f, %.0f]', deathCiTotal(1), deathCiTotal(2));

    % 第7列
    medCosts = hospCountsI .* medCost + hospCountsIV .* medCostIV; 
    outCosts = (yAgePredictedForI - hospCountsI) .* outCost + (yAgePredictedForIV - hospCountsIV) .* outCostIV; 
    totalMedCosts = sum(medCosts + outCosts) / 1e6; 
    medCostCiTotal = sum(hospCountsI' .* medCostCi + hospCountsIV' .* medCostCiIV, 1) / 1e6; 
    outCostCiTotal = sum((yAgePredictedForI - hospCountsI)' .* outCostCi + (yAgePredictedForIV - hospCountsIV)' .* outCostCiIV, 1) / 1e6;
    medCostCiTotal = medCostCiTotal + outCostCiTotal;
    medCostRange = sprintf('[%.1f, %.1f]', medCostCiTotal(1), medCostCiTotal(2));

    % 第8列
    vaccineCosts = adjustedTotalVacNum .* vaccineCost'; 
    totalVaccineCosts = sum(vaccineCosts) / 1e6; 
    vaccineCostCiTotal = sum(adjustedTotalVacNum .* vaccineCostCi, 1) / 1e6; 
    vaccineCostRange = sprintf('[%.1f, %.1f]', vaccineCostCiTotal(1), vaccineCostCiTotal(2));

    % 第9-11列
    % vaccineDiff = sum(adjustedTotalVacNum) - avr.VacNumber; 
    % vaccineCostDiff = sum(vaccineCosts) - avr.VacCost;
    if optimumType == 1
    vaccineDiff = avr.VacNumber - sum(adjustedTotalVacNum); 
    vaccineCostDiff = avr.VacCost - sum(vaccineCosts);

    avgHospReduction = vaccineDiff / (totalHospCounts - avr.HospNumber); 
    avgHospReductionCi = vaccineDiff ./ (hospCiTotal - avr.HospNumberCi);
    avgHospReductionRange = sprintf('[%.0f, %.0f]', avgHospReductionCi(2), avgHospReductionCi(1));

    avgDeathReduction = vaccineDiff / (totalDeathCounts - avr.DeathNumber); 
    avgDeathReductionCi = vaccineDiff ./ (deathCiTotal - avr.DeathNumberCi);
    avgDeathReductionRange = sprintf('[%.0f, %.0f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgInfsReduction = vaccineDiff / (totalInfections - avr.Infections); 
    RRR = (avr.Infections - totalInfections) / avr.Infections * 100;
    
    % avgInfsReductionCi = vaccineDiff ./ (deathCiTotal - avr.Infections);
    % avgInfsReductionRange = sprintf('[%.2f, %.2f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgCostReduction = vaccineCostDiff / (totalMedCosts *1e6 - avr.MediCost); 
    
    avgCostReductionCi = vaccineCostDiff ./ (medCostCiTotal *1e6 - avr.MediCostCi);
    avgCostReductionRange = sprintf('[%.2f, %.2f]', avgCostReductionCi(2), avgCostReductionCi(1));

    else 
    vaccineDiff = 0; 

    avgHospReduction = vaccineDiff / (totalHospCounts - avr.HospNumber) *1e4; 
    avgHospReductionCi = vaccineDiff ./ (hospCiTotal - avr.HospNumberCi)*1e4;
    avgHospReductionRange = sprintf('[%.0f, %.0f]', avgHospReductionCi(2), avgHospReductionCi(1));

    avgDeathReduction = vaccineDiff / (totalDeathCounts - avr.DeathNumber)*1e4;
    avgDeathReductionCi = vaccineDiff ./ (deathCiTotal - avr.DeathNumberCi)*1e4;
    avgDeathReductionRange = sprintf('[%.0f, %.0f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgInfsReduction = vaccineDiff / (totalInfections - avr.Infections) *1e6; 
    RRR = (avr.Infections - totalInfections) / avr.Infections * 100;
    % 减少 1e6 个感染病例所需要的疫苗剂数
    % avgInfsReductionCi = vaccineDiff ./ (deathCiTotal - avr.Infections);
    % avgInfsReductionRange = sprintf('[%.2f, %.2f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgCostReduction = vaccineDiff / (totalMedCosts *1e6 - avr.MediCost) *1e6;
    %每节省 1e6 单位医疗费用所需增加的疫苗费用
    avgCostReductionCi = vaccineDiff ./ (medCostCiTotal *1e6 - avr.MediCostCi) .*1e6;
    avgCostReductionRange = sprintf('[%.2f, %.2f]', avgCostReductionCi(2), avgCostReductionCi(1));

    end


if optimumType == 1
    newRow = { ...
        eco.agegroup{ageIdx}, ...
        sprintf('%s (%.0f)', vaccineCoverage, vaccineCount), ...
        sprintf('%.0f (%s)', peakCases, peakCasesPercent), ...
        sprintf('%.0f (%s)', totalInfections, totalInfectionsPercent), ...
        sprintf('%.0f %s', totalHospCounts, hospRange), ...
        sprintf('%.0f %s', totalDeathCounts, deathRange), ...
        sprintf('%.1f %s', totalMedCosts, medCostRange), ...
        sprintf('%.1f %s', totalVaccineCosts, vaccineCostRange), ...
        sprintf('%.0f %s', avgHospReduction, avgHospReductionRange), ...
        sprintf('%.0f %s', avgDeathReduction, avgDeathReductionRange), ...
        sprintf('%.2f %s', avgCostReduction, avgCostReductionRange) ...
        sprintf('%.2f', avgInfsReduction)};
     resultTable = [resultTable; newRow];
     barTable = [barTable; {eco.agegroup{ageIdx}, vacRateAdjusted, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), CIR, RRR}];
elseif optimumType == 2
        newRow = { ...
        'Week', ... 
        sprintf('%.0f (%s)', vaccineCount, vaccineCoverage), ...
        sprintf('%.0f (%s)', peakCases, peakCasesPercent), ...
        sprintf('%.0f (%s)', totalInfections, totalInfectionsPercent), ...
        sprintf('%.0f %s', totalHospCounts, hospRange), ...
        sprintf('%.0f %s', totalDeathCounts, deathRange), ...
        sprintf('%.2f %s', totalMedCosts, medCostRange), ...
        sprintf('%.1f %s', totalVaccineCosts, vaccineCostRange), ...
        sprintf('%.0f %s', avgHospReduction, avgHospReductionRange), ...
        sprintf('%.2f %s', avgDeathReduction, avgDeathReductionRange), ...
        sprintf('%.2f %s', avgCostReduction, avgCostReductionRange) ...
        sprintf('%.2f', avgInfsReduction)};
     resultTable = [resultTable; newRow];
     barTable = [barTable; {'Earlier Timing', ageIdx, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), CIR, RRR}];
elseif optimumType == 3
        newRow = { ...
        'Speed', ... 
        sprintf('%.2f (%s)', vaccineCount, vaccineCoverage), ...
        sprintf('%.0f (%s)', peakCases, peakCasesPercent), ...
        sprintf('%.0f (%s)', totalInfections, totalInfectionsPercent), ...
        sprintf('%.0f %s', totalHospCounts, hospRange), ...
        sprintf('%.0f %s', totalDeathCounts, deathRange), ...
        sprintf('%.2f %s', totalMedCosts, medCostRange), ...
        sprintf('%.1f %s', totalVaccineCosts, vaccineCostRange), ...
        sprintf('%.0f %s', avgHospReduction, avgHospReductionRange), ...
        sprintf('%.2f %s', avgDeathReduction, avgDeathReductionRange), ...
        sprintf('%.2f %s', avgCostReduction, avgCostReductionRange) ...
        sprintf('%.2f', avgInfsReduction)};
     resultTable = [resultTable; newRow];
     barTable = [barTable; {'Accelerated Rate', ageIdx, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), CIR, RRR}];
end


end

%% 将表格保存为Excel文件
resultTable = movevars(resultTable, "HICER", "Before", "Deaths");
resultTable = movevars(resultTable, 10, "Before", 8);
resultTable = movevars(resultTable, "CIICER", "Before", "Hospitalizations");
delete('optimumTable.xlsx')
delete('timeShiftTable.xlsx')

resultTable.HICER(contains(resultTable.HICER,'NaN')) = {'NaN'};
resultTable.DICER(contains(resultTable.DICER,'NaN')) = {'NaN'};
resultTable.DMCICER(contains(resultTable.DMCICER,'0.00')) = {'NaN'};

optimumTable = resultTable(contains(resultTable.AgeGroup,'age'), :);
writetable(optimumTable, 'optimumTable.xlsx');

timeShiftTable = resultTable(~contains(resultTable.AgeGroup,'age'), :);
writetable(timeShiftTable, 'timeShiftTable.xlsx');

%%  分年龄组堆叠柱状图 Optimum

optimumType = unique(barTable.AgeGroup);
colors = [194, 171, 200;
          144, 37, 37;
          242, 187, 107;
          222, 120, 51;
          112, 130, 200] / 255;  % RGB颜色矩阵
blue_color = [106 155 203]/255;

for i = 1:length(optimumType)
    tempTable = barTable(strcmp(barTable.AgeGroup, optimumType{i}), :);
    
    % 数据预处理
    stackedData = tempTable{:, 3:7} / 1000; 
    sumData = sum(stackedData, 2);  
    
    figure('Position', [100 100 1000 500])
    
    % 左轴-堆叠条形图
    yyaxis left
    b = bar(stackedData, 'stacked'); 
    
    % 设置条形颜色
    for j = 1:numel(b)
        b(j).FaceColor = colors(j,:);
        b(j).DisplayName = tempTable.Properties.VariableNames{j+2};
    end
    
    % 左轴格式设置
    ax = gca;
    ax.YAxis(1).Color = 'k';
    ax.YAxis(1).Limits = [0 max(sumData)*1.4];
    ax.YAxis(1).TickLabelFormat = '%.0fk';
    ylabel('Cumulative Infections','FontSize',8)
    
    % 添加柱顶标签（关键修复部分）
    labels = arrayfun(@(v) sprintf('%.2f%%', v*100), tempTable.CIR, 'UniformOutput', false); 
    text(1:length(sumData), sumData, labels,...  
        'HorizontalAlignment', 'center',...
        'VerticalAlignment', 'bottom',...
        'FontSize', 9,...
        'Margin', 0.5); 

    % 右轴-折线图
    yyaxis right
    p = plot(tempTable.RRR, '-o',... 
           'Color', [blue_color 0.6],...
           'MarkerSize', 6,...
           'LineWidth', 1.5,...
           'DisplayName', 'RRR');
    
    % 右轴格式设置
    ax.YAxis(2).Color = blue_color;
    ax.YAxis(2).Limits = [0 100];
    ax.YAxis(2).TickLabelFormat = '%.0f%%';
    ylabel('Relative Risk Reduction','FontSize',8)
    
    if i == 1
        xticks(1:height(tempTable))
        xLabels = tempTable.VR * 100;
        xticklabels(arrayfun(@(v) sprintf('%.2f%%', v), xLabels, 'UniformOutput', false))
        title(optimumType{i})
        xlabel('Accelerated Vaccination Rate',FontSize = 8)
        xlim([0.5 height(tempTable)+0.5])
    elseif i == 2
        xticks(1:height(tempTable))
        xLabels = tempTable.VR;
        xticklabels(xLabels)
        % xticklabels(arrayfun(@(v) sprintf('%.0f%%', v), xLabels, 'UniformOutput', false))
        title(optimumType{i})
        xlabel('Earlier Vaccination Weeks',FontSize = 8)
        xlim([0.5 height(tempTable)+0.5])
    else
        xticks(1:height(tempTable))
        xLabels = tempTable.VR * 100;
        xticklabels(arrayfun(@(v) sprintf('%.2f%%', v), xLabels, 'UniformOutput', false))
        title(optimumType{i})
        xlabel('Vaccination Coverage Rate',FontSize = 8)
        xlim([0.5 height(tempTable)+0.5])
    end
    
    % 图例
    % legend('Location', 'northeast','Box','off','FontSize',8) 
    % exportgraphics(gcf, sprintf('../../Figures/Optimum/%s.pdf', optimumType{i}),...
    %     'Resolution', 300,...
    %     'ContentType', 'vector');
end

% Accelerated Vaccination Rate