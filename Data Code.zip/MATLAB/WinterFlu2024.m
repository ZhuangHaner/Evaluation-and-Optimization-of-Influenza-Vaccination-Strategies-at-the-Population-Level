close all; clear; clc;
close all;
n = 5;  % number of subgroups 
load('VaccinationTable.mat')
load('processedTable.mat')
% %%
params.tSpan = [0, 60] + 0.5;
params.k  = 0.50;
params.omega  = 0.53;
params.omega1  = 0.83;
params.p = 0.667;
params.gamma  = 0.31;
params.gamma1  = 0.25;
params.f = 0.1;
params.n = 5;
% 1780:1840
% 疫苗效果参数
params.VEI = 0.4; % 20-40
params.VES = 0.4; % 30-40
params.VEP = 0.67; % 14-67 

aValues = linspace(0.01, 1.3, 101);
A = aValues(12) * ones(n);

B =  0 * ones(n);
C = [A(:); B(:)];

% 2023-10-22(1373),2023-12-19(1431),   
% 2024-02-13(1487) T 
% 2024-12-02(1780)  2025-01-31(1840) 

E0 = T{1779,2:6}'/params.p / params.omega * (1 - params.VES);
I0 = T{1780,2:6}' * (1 - params.VES);
A0 = [0, 0, 0, 0, 0]';
R0 = [0, 0, 0, 0, 0]';

pre27VacNum = sum(VT{1624:1707-1 - 1/params.f, 2:6})';
pre10VacNum = sum(VT{1707-1/params.f:1706, 2:6})';
% 1300:1450 ,2023-9-15,2024-2-13 VT
% 1337 ,    2023-10-22

% 1624:1765, '2024-09-10' '2025-01-31'
% 1707, '2024-12-02'
population = [103.26, 129.98, 72.28, 1413.68, 465.1]' * 1e4;
totalVacNum = sum(VT{1624:1765, 2:6})';
totalVacRate = totalVacNum ./ population;
epiVacNum = totalVacNum - pre27VacNum - pre10VacNum * 0.5;
day = days(VT.Date(1765) - VT.Date(1707)) + 1 ;
params.fai = epiVacNum / day ./ population;% 流行季节平均每日疫苗接种率

Sv0 = pre27VacNum  + pre10VacNum * 0.5;
Ev0 = T{1779,2:6}'/params.p / params.omega * params.VES;
Iv0 = T{1780,2:6}'* params.VES;
Av0 = [0, 0, 0, 0, 0]';
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates = [S0; E0; I0; A0; R0; Sv0; Ev0; Iv0; Av0];

%% 求解最优化问题

observedIncidence = T{1780:1840,2:6};
objectiveFunction = @(unknowns) computeParameterLikelihood(reshape(unknowns(1:n^2),n,n), reshape(unknowns(1+n^2:end),n,n),params, observedIncidence);

% options = optimoptions('fmincon', 'MaxFunctionEvaluations', 1e5, 'MaxIterations', 1e3, 'PlotFcn', 'optimplotfval'); 
options = optimoptions('fmincon', 'MaxFunctionEvaluations', 1e5, 'MaxIterations', 1e3); 
[D, finalErrorValue] = fmincon(objectiveFunction, C(:), [], [], [], [], ...
    [0*ones(n^2,1), -2*pi*ones(n^2,1)], [1.3*ones(n^2,1); 2*pi*ones(n^2,1)], [], options);
disp(finalErrorValue)
clear options;

estimatedA = reshape(D(1:n^2), n, n);
estimatedB = reshape(D(1+n^2:end), n, n);


% 在初始的Beta下模拟得到模型预测值
dxdt = @(t,x) computeDerivative(estimatedA, estimatedB, params, t, x);
% [tt, xPredicted] = ode23s(dxdt, params.tSpan, params.initialStates);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
yPredicted = params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n); % omega * E

figure; heatmap(estimatedA)
figure; heatmap(estimatedB)
fig = figure;
fig.Position = [248.2,291.4,1374.4,584];
tiledlayout(2,1)
ax1 = nexttile; plot(T{1780:1840,2:6});
legend('age1','age2','age3','age4','age5')
ax2 = nexttile; plot(tt, yPredicted);
legend('age1','age2','age3','age4','age5')
ax2.YLim = ax1.YLim;

writematrix(estimatedA, 'estimatedA3.xlsx');
writematrix(estimatedB, 'estimatedB3.xlsx');

%% 画出拟合效果R方图
ageGroups = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};
timeActual = datetime(2024,12,02) + caldays(0:(1840-1780));

% colors = ["#f7df87", "#eca680", "#7ac7e2", "#e3716e", "#54beaa"]; 
colors = ["#C2ABC8", "#902525", "#F2BB6B", "#DE7833", "#7082C8"];
fig = figure;
fig.Position = [248.2,291.4,1374.4,584];
tiledlayout(1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

nexttile;
hActual = plot(timeActual, T{1780:1840, 2:6});
hold on;

for i = 1:length(hActual)
    set(hActual(i), 'LineWidth', 1.5, 'Color', colors(i)); 
end

xlim([datetime(2024,12,02) datetime(2025,01,31)]);
xticksDates = linspace(datetime(2024,12,02), datetime(2025,01,31), 5);
set(gca, 'XTick', xticksDates);
datetick('x', 'yyyy-mm-dd', 'keepticks', 'keeplimits');
xlabel('Date');

ylabel('New Cases');
ylim([0, max(ylim) * 1.1]);
yticks1 = get(gca, 'YTick'); 
yticklabels1 = strcat(string(yticks1/1000), 'k'); 
set(gca, 'YTickLabel', yticklabels1);

timePredicted = datetime(2024,12,02) + days(tt - tt(1));
hFitted = plot(timePredicted, yPredicted, '--');

for i = 1:length(hActual)
    set(hFitted(i), 'Color', colors(i), 'LineWidth', 1.5);
end

legendLabels = [strcat(ageGroups, ' (Actual)'), strcat(ageGroups, ' (Fitted)')];
legend([hActual; hFitted], legendLabels, 'Location', 'northeast');

text(datetime(2024,12,04), max(ylim) * 0.95, 'A', 'FontSize', 14, 'FontWeight', 'bold');

R2_values = zeros(1, 5); 

for i = 1:5
    alignedFitted = interp1(timePredicted, yPredicted(:, i), timeActual, 'linear', 'extrap');
    actualValues = T{1780:1840, i + 1}; 
    ResidualSumSquares = sum((actualValues - alignedFitted').^2);
    TotalSumSquares = sum((actualValues - mean(actualValues)).^2);
    R2_values(i) = 1 - ResidualSumSquares / TotalSumSquares;
end

text(datetime(2025,01,24), max(T{1780:1840, 5}) * 0.65, ...
    sprintf('R^2 = %.2f', R2_values(1)), ...
    'Color', colors(1), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

text(datetime(2025,01,24), max(T{1780:1840, 5}) * 0.6, ...
    sprintf('R^2 = %.2f', R2_values(2)), ...
    'Color', colors(2), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

text(datetime(2025,01,24), max(T{1780:1840, 5}) * 0.55, ...
    sprintf('R^2 = %.2f', R2_values(3)), ...
    'Color', colors(3), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

text(datetime(2025,01,24), max(T{1780:1840, 5}) * 0.7, ...
    sprintf('R^2 = %.2f', R2_values(4)), ...
    'Color', colors(4), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

text(datetime(2025,01,24), max(T{1780:1840, 5}) * 0.5, ...
    sprintf('R^2 = %.2f', R2_values(5)), ...
    'Color', colors(5), 'FontSize', 12, 'FontWeight', 'bold', ...
    'HorizontalAlignment', 'center');

totalT = sum(T{1780:1840, 2:6}, 2);
totalyPredicted = sum(yPredicted, 2);

nexttile;
hTotalActual = plot(timeActual, totalT, 'Color', [0.349, 0.612, 0.749], 'LineWidth', 1.5);
hold on;

hTotalFitted = plot(timePredicted, totalyPredicted, 'Color', [0.761, 0.341, 0.349], 'LineStyle', '--', 'LineWidth', 1.5);

xlim([datetime(2024,12,02) datetime(2025,01,31)]);
set(gca, 'XTick', xticksDates);
datetick('x', 'yyyy-mm-dd', 'keepticks', 'keeplimits');
xlabel('Date');
yticks2 = get(gca, 'YTick');
yticklabels2 = strcat(string(yticks2/1000), 'k');
set(gca, 'YTickLabel', yticklabels2);

legend([hTotalActual, hTotalFitted], {'Actual Daily Cases', 'Fitted Daily Cases'}, 'Location', 'northeast');
text(datetime(2024,12,04), max(ylim) * 0.95, 'B', 'FontSize', 14, 'FontWeight', 'bold');

AlignedYPredicted = interp1(timePredicted, yPredicted, timeActual, 'linear');
TotalActualCases = sum(T{1780:1840, 2:6}, 2);
TotalPredictedCases = sum(AlignedYPredicted, 2);
ResidualSumSquares = sum((TotalActualCases - TotalPredictedCases).^2);
TotalSumSquares = sum((TotalActualCases - mean(TotalActualCases)).^2);
TotalRSquared = 1 - ResidualSumSquares / TotalSumSquares;

text(datetime(2025,01,24), max(ylim) * 0.85, sprintf('R^2 = %.2f', TotalRSquared), ...
    'FontSize', 12, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');

% exportgraphics(fig, ['../Figures/' 'Comparison of Daily Cases for Beijing 2024 Flu.pdf'], 'Resolution', 300);

%% 画出拟合的振幅相位图
% estimatedA = readmatrix('estimatedA3.xlsx');
% estimatedB = readmatrix('estimatedB3.xlsx');
customColorsPositiveLimited = interp1(linspace(0, 1, 3), ...
    [234/255, 255/255, 246/255; 152/255, 202/255, 221/255; 97/255, 170/255, 207/255], linspace(0, 1, 256));

customColorsNegativePositive = interp1(linspace(0, 1, 6), [
    218/255, 149/255, 153/255; 
    233/255, 198/255, 198/255; 
    249/255, 239/255, 239/255; 
    234/255, 255/255, 246/255; 
    152/255, 202/255, 221/255; 
    97/255, 170/255, 207/255   
], linspace(0, 1, 256));

fig = figure('Position', [100, 100, 1200, 600]);
tiledlayout(1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');


fontSize = 10;
labelFontSize = 14;
axisFontSize = 12; 

nexttile;
imagesc(round(estimatedA, 2));  
colormap(gca, customColorsPositiveLimited);
h = colorbar('FontSize', axisFontSize); 
h.Ticks = linspace(0, max(estimatedA(:)), 5);
h.TickLabels = cellstr(num2str(h.Ticks', '%.1f'));
clim([0, max(estimatedA(:))]);
text(0.7, 0.5, 'A', 'FontSize', labelFontSize, 'FontWeight', 'bold', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
title('Fitted Amplitude for 2024 Influenza', 'FontSize', fontSize, 'FontWeight', 'normal');
set(gca, 'YTick', 1:5, 'XTick', 1:5);
yticklabels({'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'});
xticklabels({'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'});
set(gca, 'FontSize', axisFontSize); 

textStrings = num2str(estimatedA(:), '%.2f');
textStrings = strtrim(cellstr(textStrings));
[x, y] = meshgrid(1:size(estimatedA, 2), 1:size(estimatedA, 1));
text(x(:), y(:), textStrings, 'HorizontalAlignment', 'center', 'FontSize', axisFontSize - 1, 'Color', [0 0 0 0.6]); 

nexttile;
imagesc(round(estimatedB, 2)); 
colormap(gca, customColorsNegativePositive);
h = colorbar('FontSize', axisFontSize);

minB = min(estimatedB(:));
maxB = max(estimatedB(:));
climRange = max(abs(minB), abs(maxB)); 
clim([-climRange, climRange]); 

h.Ticks = linspace(-climRange, climRange, 5);
h.TickLabels = sprintfc('%.2fπ', h.Ticks / pi);

text(0.7, 0.5, 'B', 'FontSize', labelFontSize, 'FontWeight', 'bold', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
title('Fitted Phase for 2024 Influenza', 'FontSize', fontSize, 'FontWeight', 'normal');
set(gca, 'YTick', [], 'XTick', 1:5);
xticklabels({'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'});
set(gca, 'FontSize', axisFontSize);

textStrings = strcat(num2str(round(estimatedB(:) / pi, 2), '%.2f'), {'π'});
textStrings = strtrim(cellstr(textStrings)); 
text(x(:), y(:), textStrings, 'HorizontalAlignment', 'center', 'FontSize', axisFontSize - 1);

% exportgraphics(fig, ['../Figures/' 'Fitted Amplitude and Phase for 2024 Flu.png'], 'Resolution', 300, 'ContentType', 'vector');

%% 画出疫苗效果评估图， 创建评估表格  
% estimatedA = readmatrix('estimatedA3.xlsx');
% estimatedB = readmatrix('estimatedB3.xlsx');

% M 是1百万
resultTable = cell2table(cell(0, 12), ...
    'VariableNames', {'AgeGroup', 'VaccineCoverage', 'PeakCases', 'TotalInfections', ...
                      'Hospitalizations', 'Deaths', 'MedicalCost(M)', ...
                      'VaccineCost(M)', 'HICER', 'DICER',  'DMCICER', 'CIICER'});
% 柱状图表格 CIR:cumulative infection rate。  RRR：Relative Risk Reduction
barTable = cell2table(cell(0, 9), ...
    'VariableNames', {'AgeGroup', 'VR', 'age0-5', 'age6-12', 'age13-18', ...
                      'age19-59', 'age60+', 'CIR', 'RRR'});

eco.agegroup = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};
eco.HospRate = [313, 76, 2, 7, 53]/1e5;
eco.HospRateForIV = eco.HospRate * 0.5; %
eco.HospCI = [[280, 349]; [61, 95]; [0, 8]; [3, 14]; [41 70]]/1e5;
eco.HospCIForIV = eco.HospCI * 0.5; %
eco.DeathRate = [0, 0, 0, 0.002, 0.015];
eco.DeathRateForIV = eco.DeathRate * 0.5; %
eco.DeathCI = [[0, 0.0001]; [0, 0.0001]; [0, 0.0001]; [0.001, 0.003]; [0.005, 0.015]];
eco.DeathCIForIV = eco.DeathCI * 0.5; %
eco.MedCost = [231, 231, 231, 854, 1776.7];
eco.MedCostForIV = eco.MedCost * 0.5; %
eco.MedCostCI = [[149, 313]; [149, 313]; [149, 313];  [409, 1299]; [1234.6, 2318.8]];
eco.MedCostCIForIV = eco.MedCostCI * 0.5; %
eco.VaccineCost = [23.74, 23.74, 23.74, 23.74, 23.74];
eco.VaccineCostCI = [[17.48, 30]; [17.48, 30]; [17.48, 30]; [17.48, 30]; [17.48, 30]];
eco.OutCost = [61.6, 22.8, 22.8, 22.8, 31];
eco.OutCostForIV = eco.OutCost * 0.5; %
eco.OutCostCI = [[56, 67.1]; [20.9, 24.8]; [20.9, 24.8]; [20.9, 24.8]; [11, 64]];
eco.OutCostCIForIV = eco.OutCostCI * 0.5; %


fig = figure;
set(fig, 'Units', 'normalized', 'OuterPosition', [0 0 1 1]);
tiledlayout(3, 3, 'TileSpacing', 'Compact');

colors = [
    0, 18, 25;
    0, 96, 115;
    9, 147, 150;
    145, 211, 192;
    235, 215, 165;
    238, 155, 0;
    204, 102, 2;
    188, 62, 3;
    174, 32, 18;
    155, 34, 39
] / 255;

adjustedVacRates = [0.015, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6];
initialVacRate = totalVacRate;
popuEstimateVacRate = sort([0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.10], 'descend'); 
initialTotalVacNum = sum(totalVacNum);
ageGroups = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};
timeRange = T.Date(1780):T.Date(1840);
timeDays = linspace(0.5, length(timeRange) - 0.5, length(timeRange));
evaluationType = 1;
for ageIdx = 1:n
    nexttile;
    hold on;

    adjustedTotalVacNum = totalVacNum;
    params.fai = epiVacNum / day ./ population;

    pre27VacNumAdjusted = pre27VacNum;
    pre10VacNumAdjusted = pre10VacNum;

    Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
    S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
    params.initialStates(1:n) = S0;
    params.initialStates(5*n+1:6*n) = Sv0;

    dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
    [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

    casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
    casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
%%% 
    yPredicted = params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n); 
    yPredictedForI = params.p * params.omega * xPredicted(:, n+1:2*n);
    yPredictedForIV = params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n);
    yAgePredictedForI = trapz(tt, yPredictedForI);
    yAgePredictedForIV = trapz(tt, yPredictedForIV);
    
    avr.HospNumber = sum(yAgePredictedForI .* eco.HospRate + yAgePredictedForIV .* eco.HospRateForIV);
    avr.DeathNumber = sum(yAgePredictedForI .* eco.DeathRate + yAgePredictedForIV .* eco.DeathRateForIV);
    avr.Infections = sum(yAgePredictedForI + yAgePredictedForIV);
    avr.MediCost = sum(yAgePredictedForI .* eco.HospRate .* eco.MedCost + ...
    yAgePredictedForI .* (1 - eco.HospRate) .* eco.OutCost + ...
    yAgePredictedForIV .* eco.HospRateForIV .* eco.MedCostForIV + ...
    yAgePredictedForIV .* (1 - eco.HospRateForIV) .* eco.OutCostForIV);
    avr.VacNumber = sum(totalVacNum);
    avr.VacCost = sum(totalVacNum' .* eco.VaccineCost);

    avr.MediCostCi = [6.9824   10.5670]*1e6; %%%%%% 改参数需要更新
    avr.HospNumberCi = [190.0686  266.9001]; 
    avr.DeathNumberCi = [0.3313    1.0047]*1e3; 
    %%%
    [resultTable, barTable] = updateResultTable(resultTable, ageIdx, totalVacRate(ageIdx), ...
                                    adjustedTotalVacNum,  ...
                                    casesPredictedInterp, population, ...
                                    eco, params, avr, evaluationType, xPredicted, tt, barTable);
    %%%


    plot(timeRange, casesPredictedInterp, 'LineWidth', 1.5, 'Color', colors(1, :), ...
         'DisplayName', ['VR = ' num2str(round(initialVacRate(ageIdx) * 100, 2)) '%']);
    title(ageGroups{ageIdx})
% adjustedVacRates = [0.015, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6];
    if ageIdx == 4
        vacRateAdjustments = [0.01, 0.015];
    elseif ageIdx == 5
        vacRateAdjustments = [0.015, 0.03, 0.05, 0.1, 0.15];
    else
        vacRateAdjustments = adjustedVacRates(adjustedVacRates < initialVacRate(ageIdx));
    end

    vacRateAdjustments = sort(vacRateAdjustments, 'descend');

    for i = 1:length(vacRateAdjustments)
        vacRateAdjusted = vacRateAdjustments(i);
        currentVacFactor = vacRateAdjusted / initialVacRate(ageIdx);
        pre27VacNumAdjusted(ageIdx) = pre27VacNum(ageIdx) * currentVacFactor;
        pre10VacNumAdjusted(ageIdx) = pre10VacNum(ageIdx) * currentVacFactor;

        adjustedTotalVacNum(ageIdx) = totalVacNum(ageIdx) * currentVacFactor;
        epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;
        params.fai = epiVacNumAdjusted / day ./ population;

        Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
        S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
        params.initialStates(1:n) = S0;
        params.initialStates(5*n+1:6*n) = Sv0;

        dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
        [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
        
        casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
        casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
        [resultTable, barTable] = updateResultTable(resultTable, ageIdx, vacRateAdjusted, ...
                                adjustedTotalVacNum,  ...
                                casesPredictedInterp, population, ...
                                eco, params, avr, evaluationType, xPredicted, tt, barTable);

        plot(timeRange, casesPredictedInterp, 'LineWidth', 1, 'Color', colors(min(i+1, size(colors, 1)), :), ...
             'DisplayName', ['VR = ' num2str(round(vacRateAdjusted * 100, 2)) '%']);
    end

    hold off;

    if ismember(ageIdx, [1, 4])
        ylabel('Infectious population','FontSize',8);
    end

    xlim([timeRange(1), timeRange(end)]);
    drawnow;
    % xtickformat('yyyy-MM');

    yticks = get(gca, 'YTick');
    yticklabels = arrayfun(@(y) sprintf('%dk', y), yticks, 'UniformOutput', false);
    set(gca, 'YTickLabel', yticklabels);
    % if ageIdx == 2
    %     lgd = legend('show', 'NumColumns', 3);
    %     lgd.FontSize = 6;  
    % 
    % else
        legend('FontSize',6,'Box','off');
        legend show
    % end

end

nexttile
hold on;
evaluationType = 2;
pre27VacNumAdjusted = pre27VacNum;
pre10VacNumAdjusted = pre10VacNum;
adjustedTotalVacNum = totalVacNum;
epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;

params.fai = epiVacNumAdjusted / day ./ population;

Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;

dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
popuVacRate = sum(totalVacNum) / sum(population);

[resultTable, barTable] = updateResultTable(resultTable, 1, popuVacRate, ...
                                adjustedTotalVacNum,  ...
                                casesPredictedInterp, population, ...
                                eco, params, avr, evaluationType, xPredicted, tt, barTable);
plot(timeRange, casesPredictedInterp, 'LineWidth', 1.5, 'Color', colors(1, :), ...
     'DisplayName', ['PVR = ' num2str(round(popuVacRate * 100, 2)) '%']);
title('PVR')
for i = 2:length(popuEstimateVacRate)
    vacRateFactor = popuEstimateVacRate(i) / popuVacRate;
    pre27VacNumAdjusted = pre27VacNum * vacRateFactor;
    pre10VacNumAdjusted = pre10VacNum * vacRateFactor;
    adjustedTotalVacNum = totalVacNum * vacRateFactor;
    epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;

    params.fai = epiVacNumAdjusted / day ./ population;
    Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
    S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
    params.initialStates(1:n) = S0;
    params.initialStates(5*n+1:6*n) = Sv0;

    dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
    [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
    casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
    casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
    [resultTable, barTable] = updateResultTable(resultTable, i, popuEstimateVacRate(i), ...
                                    adjustedTotalVacNum,  ...
                                    casesPredictedInterp, population, ...
                                    eco, params, avr, evaluationType, xPredicted, tt, barTable);
    plot(timeRange, casesPredictedInterp, 'LineWidth', 1, 'Color', colors(min(i+1, size(colors, 1)), :), ...
         'DisplayName', ['PVR = ' num2str(round(popuEstimateVacRate(i) * 100, 2)) '%']);
end

xlim([timeRange(1), timeRange(end)]);
% xtickformat('yyyy-MM');

yticks = get(gca, 'YTick');
yticklabels = arrayfun(@(y) sprintf('%dk', y), yticks, 'UniformOutput', false);
set(gca, 'YTickLabel', yticklabels);
legend('FontSize',6,'Box','off');
legend show;
%%%%%% 8
nexttile(8);
hold on;
evaluationType = 3;
pre27VacNumAdjusted = pre27VacNum;
pre10VacNumAdjusted = pre10VacNum;
adjustedTotalVacNum = totalVacNum;
epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;

params.fai = epiVacNumAdjusted / day ./ population;
Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;

dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
specificVacRate = sum(adjustedTotalVacNum([2, 3, 5])) / sum(population([2, 3, 5]));
[resultTable, barTable] = updateResultTable(resultTable, 1, specificVacRate, ...
                                adjustedTotalVacNum,  ...
                                casesPredictedInterp, population, ...
                                eco, params, avr, evaluationType, xPredicted, tt, barTable);

plot(timeRange, casesPredictedInterp, 'LineWidth', 1.5, 'Color', colors(1, :), ...
     'DisplayName', 'SVR');
title('SVR(2 3 5)')
vacRateAdjustments = [0.18, 0.15, 0.12, 0.09, 0.06, 0.03, 0.02, 0.01];

for i = 1:length(vacRateAdjustments)
    vacRateFactor = vacRateAdjustments(i) ./ initialVacRate([2, 3, 5]);
    pre27VacNumAdjusted([2, 3, 5]) = pre27VacNum([2, 3, 5]) .* vacRateFactor;
    pre10VacNumAdjusted([2, 3, 5]) = pre10VacNum([2, 3, 5]) .* vacRateFactor;
    adjustedTotalVacNum([2, 3, 5]) = totalVacNum([2, 3, 5]) .* vacRateFactor;
    
    epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;
    params.fai = epiVacNumAdjusted / day ./ population;

    Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
    S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
    params.initialStates(1:n) = S0;
    params.initialStates(5*n+1:6*n) = Sv0;

    dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
    [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

    casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
    casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
    [resultTable, barTable] = updateResultTable(resultTable, i, vacRateAdjustments(i), ...
                                    adjustedTotalVacNum,  ...
                                    casesPredictedInterp, population, ...
                                    eco, params, avr, evaluationType, xPredicted, tt, barTable);
    plot(timeRange, casesPredictedInterp, 'LineWidth', 1, 'Color', colors(min(i+1, size(colors, 1)), :), ...
         'DisplayName', ['SVR = ' num2str(vacRateAdjustments(i) * 100, '%.0f') '%']);
end

ylabel('Infectious population','FontSize',8);
xlabel('Date','FontSize',8);
xlim([timeRange(1), timeRange(end)]);
% xtickformat('yyyy-MM');

yticks = get(gca, 'YTick');
yticklabels = arrayfun(@(y) sprintf('%dk', y), yticks, 'UniformOutput', false);
set(gca, 'YTickLabel', yticklabels);
legend('FontSize',6,'Box','off');
legend show;
hold off;

annotation('textbox', [0.07, 0.87, 0.05, 0.05], 'String', 'A', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.37, 0.87, 0.05, 0.05], 'String', 'B', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.67, 0.87, 0.05, 0.05], 'String', 'C', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.07, 0.58, 0.05, 0.05], 'String', 'D', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.37, 0.58, 0.05, 0.05], 'String', 'E', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.67, 0.58, 0.05, 0.05], 'String', 'F', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.37, 0.29, 0.05, 0.05], 'String', 'G', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');

% exportgraphics(gcf, ['../Figures/' 'Evaluation of 2024 vaccination.pdf'], Resolution=300);

%% 疫苗评估表格函数
function [resultTable, barTable] = updateResultTable(resultTable, ageIdx, vacRateAdjusted, ...
                                         adjustedTotalVacNum,  ...
                                         casesPredicted, population, ...
                                         eco, params, avr, evaluationType, xPredicted, tt, barTable)
    n = params.n;
    
    hospRate = eco.HospRate; 
    hospCi = eco.HospCI;     
    deathRate = eco.DeathRate; 
    deathCi = eco.DeathCI;     
    medCost = eco.MedCost;   
    medCostCi = eco.MedCostCI;
    vaccineCost = eco.VaccineCost; 
    vaccineCostCi = eco.VaccineCostCI;
    outCost = eco.OutCost; 
    outCostCi = eco.OutCostCI;

    hospRateIV = eco.HospRateForIV; 
    hospCiIV = eco.HospCIForIV;     
    deathRateIV = eco.DeathRateForIV;
    deathCiIV = eco.DeathCIForIV;    
    medCostIV = eco.MedCostForIV;   
    medCostCiIV = eco.MedCostCIForIV;
    outCostIV = eco.OutCostForIV; 
    outCostCiIV = eco.OutCostCIForIV;
    

    % 第2列
    if evaluationType == 1
    vaccineCount = adjustedTotalVacNum(ageIdx);
    vaccineCoverage = sprintf('%.2f%%', vacRateAdjusted * 100);
    elseif evaluationType == 2
    vaccineCount = sum(adjustedTotalVacNum);
    vaccineCoverage = sprintf('%.2f%%', vacRateAdjusted * 100);
    else
    vaccineCount = sum(adjustedTotalVacNum([2, 3, 5]));
    vaccineCoverage = sprintf('%.2f%%', vacRateAdjusted * 100);
    end
    % 第3列
    peakCases = max(casesPredicted) * 1000;
    peakCasesPercent = sprintf('%.2f‰', (peakCases / sum(population)) * 1000);

    % 第4列
    yPredictedForI = params.p * params.omega * xPredicted(:, n+1:2*n);
    yPredictedForIV = params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n);
    yAgePredictedForI = trapz(tt, yPredictedForI); 
    yAgePredictedForIV = trapz(tt, yPredictedForIV); 
    ageInfection = yAgePredictedForI + yAgePredictedForIV;
    totalInfections = sum(ageInfection); 
    CIR = totalInfections / sum(population);
    totalInfectionsPercent = sprintf('%.2f%%', CIR * 100);

    % 第5列
    hospCountsI = yAgePredictedForI .* hospRate; 
    hospCountsIV = yAgePredictedForIV .* hospRateIV; 
    totalHospCounts = sum(hospCountsI + hospCountsIV);
    hospCiTotal = sum(yAgePredictedForI' .* hospCi + yAgePredictedForIV' .* hospCiIV, 1); 
    hospRange = sprintf('[%.0f, %.0f]', hospCiTotal(1), hospCiTotal(2));

    % 第6列
    deathCountsI = yAgePredictedForI .* deathRate; 
    deathCountsIV = yAgePredictedForIV .* deathRateIV;
    totalDeathCounts = sum(deathCountsI + deathCountsIV);
    deathCiTotal = sum(yAgePredictedForI' .* deathCi + yAgePredictedForIV' .* deathCiIV, 1); 
    deathRange = sprintf('[%.0f, %.0f]', deathCiTotal(1), deathCiTotal(2));

    % 第7列
    medCosts = hospCountsI .* medCost + hospCountsIV .* medCostIV; 
    outCosts = (yAgePredictedForI - hospCountsI) .* outCost + (yAgePredictedForIV - hospCountsIV) .* outCostIV; 
    totalMedCosts = sum(medCosts + outCosts) / 1e6;
    medCostCiTotal = sum(hospCountsI' .* medCostCi + hospCountsIV' .* medCostCiIV, 1) / 1e6;
    outCostCiTotal = sum((yAgePredictedForI - hospCountsI)' .* outCostCi + (yAgePredictedForIV - hospCountsIV)' .* outCostCiIV, 1) / 1e6;
    medCostCiTotal = medCostCiTotal + outCostCiTotal;
    medCostRange = sprintf('[%.1f, %.1f]', medCostCiTotal(1), medCostCiTotal(2));

    % 第8列
    vaccineCosts = adjustedTotalVacNum .* vaccineCost';
    totalVaccineCosts = sum(vaccineCosts) / 1e6;
    vaccineCostCiTotal = sum(adjustedTotalVacNum .* vaccineCostCi, 1) / 1e6; 
    vaccineCostRange = sprintf('[%.1f, %.1f]', vaccineCostCiTotal(1), vaccineCostCiTotal(2));

    % 第9-11列
    vaccineDiff = avr.VacNumber - sum(adjustedTotalVacNum);
    vaccineCostDiff = avr.VacCost - sum(vaccineCosts);

    avgHospReduction = vaccineDiff / (totalHospCounts - avr.HospNumber); 
    avgHospReductionCi = vaccineDiff ./ (hospCiTotal - avr.HospNumberCi);
    avgHospReductionRange = sprintf('[%.0f, %.0f]', avgHospReductionCi(2), avgHospReductionCi(1));

    avgDeathReduction = vaccineDiff / (totalDeathCounts - avr.DeathNumber);
    avgDeathReductionCi = vaccineDiff ./ (deathCiTotal - avr.DeathNumberCi);
    avgDeathReductionRange = sprintf('[%.0f, %.0f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgInfsReduction = vaccineDiff / (totalInfections - avr.Infections); 
    RRR = (totalInfections - avr.Infections) / totalInfections * 100;
    
    % avgInfsReductionCi = vaccineDiff ./ (deathCiTotal - avr.Infections);
    % avgInfsReductionRange = sprintf('[%.2f, %.2f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgCostReduction = vaccineCostDiff / (totalMedCosts *1e6 - avr.MediCost);
    avgCostReductionCi = vaccineCostDiff ./ (medCostCiTotal *1e6 - avr.MediCostCi);
    avgCostReductionRange = sprintf('[%.2f, %.2f]', avgCostReductionCi(2), avgCostReductionCi(1));


if evaluationType == 1
    newRow = { ...
        eco.agegroup{ageIdx}, ... 
        sprintf('%s (%.0f)', vaccineCoverage, vaccineCount), ...
        sprintf('%.0f (%s)', peakCases, peakCasesPercent), ...
        sprintf('%.0f (%s)', totalInfections, totalInfectionsPercent), ...
        sprintf('%.0f %s', totalHospCounts, hospRange), ...
        sprintf('%.0f %s', totalDeathCounts, deathRange), ...
        sprintf('%.1f %s', totalMedCosts, medCostRange), ...
        sprintf('%.1f %s', totalVaccineCosts, vaccineCostRange), ...
        sprintf('%.0f %s', avgHospReduction, avgHospReductionRange), ...
        sprintf('%.0f %s', avgDeathReduction, avgDeathReductionRange), ...
        sprintf('%.2f %s', avgCostReduction, avgCostReductionRange) ...
        sprintf('%.2f', avgInfsReduction)};
     resultTable = [resultTable; newRow];
     % newRow = {eco.agegroup{ageIdx}, vaccineCoverage, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), totalInfectionsPercent, RRR};
     barTable = [barTable; {eco.agegroup{ageIdx}, vacRateAdjusted, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), CIR, RRR}];
elseif evaluationType == 2
        newRow = { ...
        'PVR', ... 
        sprintf('%s (%.0f)', vaccineCoverage, vaccineCount), ...
        sprintf('%.0f (%s)', peakCases, peakCasesPercent), ...
        sprintf('%.0f (%s)', totalInfections, totalInfectionsPercent), ...
        sprintf('%.0f %s', totalHospCounts, hospRange), ...
        sprintf('%.0f %s', totalDeathCounts, deathRange), ...
        sprintf('%.1f %s', totalMedCosts, medCostRange), ...
        sprintf('%.1f %s', totalVaccineCosts, vaccineCostRange), ...
        sprintf('%.0f %s', avgHospReduction, avgHospReductionRange), ...
        sprintf('%.0f %s', avgDeathReduction, avgDeathReductionRange), ...
        sprintf('%.2f %s', avgCostReduction, avgCostReductionRange) ...
        sprintf('%.2f', avgInfsReduction)};
     resultTable = [resultTable; newRow];
     barTable = [barTable; {'PVR', vacRateAdjusted, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), CIR, RRR}];
else
            newRow = { ...
        'SVR(2 3 5)', ... 
        sprintf('%s (%.0f)', vaccineCoverage, vaccineCount), ...
        sprintf('%.0f (%s)', peakCases, peakCasesPercent), ...
        sprintf('%.0f (%s)', totalInfections, totalInfectionsPercent), ...
        sprintf('%.0f %s', totalHospCounts, hospRange), ...
        sprintf('%.0f %s', totalDeathCounts, deathRange), ...
        sprintf('%.1f %s', totalMedCosts, medCostRange), ...
        sprintf('%.1f %s', totalVaccineCosts, vaccineCostRange), ...
        sprintf('%.0f %s', avgHospReduction, avgHospReductionRange), ...
        sprintf('%.0f %s', avgDeathReduction, avgDeathReductionRange), ...
        sprintf('%.2f %s', avgCostReduction, avgCostReductionRange) ...
        sprintf('%.2f', avgInfsReduction)};
     resultTable = [resultTable; newRow];
     barTable = [barTable; {'SVR(2 3 5)', vacRateAdjusted, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), CIR, RRR}];
end

end

%% 表格修理并保存
resultTable = movevars(resultTable, "HICER", "Before", "Deaths");
resultTable = movevars(resultTable, 10, "Before", 8);
resultTable = movevars(resultTable, "CIICER", "Before", "Hospitalizations");
delete('2024Estimate.xlsx')

resultTable.HICER(contains(resultTable.HICER,'NaN')) = {'NaN'};
resultTable.DICER(contains(resultTable.DICER,'NaN')) = {'NaN'};
resultTable.DMCICER(contains(resultTable.DMCICER,'0.00')) = {'NaN'};

writetable(resultTable, '2024Estimate.xlsx');

%%  分年龄组堆叠柱状图 Estimate

estimateType = unique(barTable.AgeGroup);
colors = [194, 171, 200;
          144, 37, 37;
          242, 187, 107;
          222, 120, 51;
          112, 130, 200] / 255;  % RGB颜色矩阵
blue_color = [106 155 203]/255;

for i = 1:length(estimateType)
    tempTable = barTable(strcmp(barTable.AgeGroup, estimateType{i}), :);

    % 数据预处理
    stackedData = tempTable{:, 3:7} / 1000; 
    sumData = sum(stackedData, 2);  

    figure('Position', [100 100 1000 500])

    % 左轴-堆叠条形图
    yyaxis left
    b = bar(stackedData, 'stacked'); 

    % 设置条形颜色
    for j = 1:numel(b)
        b(j).FaceColor = colors(j,:);
        b(j).DisplayName = tempTable.Properties.VariableNames{j+2};
    end

    % 左轴格式设置
    ax = gca;
    ax.YAxis(1).Color = 'k';
    ax.YAxis(1).Limits = [0 max(sumData)*1.4];
    ax.YAxis(1).TickLabelFormat = '%.0fk';
    ylabel('Cumulative Infections','FontSize',8)

    % 添加柱顶标签（关键修复部分）
    labels = arrayfun(@(v) sprintf('%.2f%%', v*100), tempTable.CIR, 'UniformOutput', false); 
    text(1:length(sumData), sumData, labels,...  
        'HorizontalAlignment', 'center',...
        'VerticalAlignment', 'bottom',...
        'FontSize', 9,...
        'Margin', 0.5); 

    % 右轴-折线图
    yyaxis right
    p = plot(tempTable.RRR, '-o',... 
           'Color', [blue_color 0.6],...
           'MarkerSize', 6,...
           'LineWidth', 1.5,...
           'DisplayName', 'RRR');

    % 右轴格式设置
    ax.YAxis(2).Color = blue_color;
    ax.YAxis(2).Limits = [0 100];
    ax.YAxis(2).TickLabelFormat = '%.0f%%';
    ylabel('Relative Risk Reduction','FontSize',8)

    % 公共设置
    xticks(1:height(tempTable))
    xLabels = tempTable.VR * 100;
    xticklabels(arrayfun(@(v) sprintf('%.2f%%', v), xLabels, 'UniformOutput', false))
    title(estimateType{i})
    xlabel('Vaccination Coverage Rate',FontSize = 8)
    xlim([0.5 height(tempTable)+0.5])

    % 图例
    % legend('Location', 'northeast','Box','off','FontSize',8) 
    % exportgraphics(gcf, sprintf('../Figures/Estimate/2024%s.pdf', estimateType{i}),...
    %     'Resolution', 300,... 
    %     'ContentType', 'vector');
end

%%  画出疫苗效果优化图， 创建评估表格  
%   M 是1百万
resultTable = cell2table(cell(0, 12), ...
    'VariableNames', {'AgeGroup', 'VaccineCoverage', 'PeakCases', 'TotalInfections', ...
                      'Hospitalizations', 'Deaths', 'MedicalCost(M)', ...
                      'VaccineCost(M)', 'HICER', 'DICER',  'DMCICER', 'CIICER'});

% 柱状图表格 CIR:cumulative infection rate。  RRR：Relative Risk Reduction
barTable = cell2table(cell(0, 9), ...
    'VariableNames', {'AgeGroup', 'VR', 'age0-5', 'age6-12', 'age13-18', ...
                      'age19-59', 'age60+', 'CIR', 'RRR'});

eco.agegroup = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};
eco.HospRate = [313, 76, 2, 7, 53]/1e5;
eco.HospRateForIV = eco.HospRate * 0.5; %
eco.HospCI = [[280, 349]; [61, 95]; [0, 8]; [3, 14]; [41 70]]/1e5;
eco.HospCIForIV = eco.HospCI * 0.5; %
eco.DeathRate = [0, 0, 0, 0.002, 0.015];
eco.DeathRateForIV = eco.DeathRate * 0.5; %
eco.DeathCI = [[0, 0.0001]; [0, 0.0001]; [0, 0.0001]; [0.001, 0.003]; [0.005, 0.015]];
eco.DeathCIForIV = eco.DeathCI * 0.5; %
eco.MedCost = [231, 231, 231, 854, 1776.7];
eco.MedCostForIV = eco.MedCost * 0.5; %
eco.MedCostCI = [[149, 313]; [149, 313]; [149, 313];  [409, 1299]; [1234.6, 2318.8]];
eco.MedCostCIForIV = eco.MedCostCI * 0.5; %
eco.VaccineCost = [23.74, 23.74, 23.74, 23.74, 23.74];
eco.VaccineCostCI = [[17.48, 30]; [17.48, 30]; [17.48, 30]; [17.48, 30]; [17.48, 30]];
eco.OutCost = [61.6, 22.8, 22.8, 22.8, 31];
eco.OutCostForIV = eco.OutCost * 0.5; %
eco.OutCostCI = [[56, 67.1]; [20.9, 24.8]; [20.9, 24.8]; [20.9, 24.8]; [11, 64]];
eco.OutCostCIForIV = eco.OutCostCI * 0.5; %

adjustedVacRates = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.75, 0.8];
initialVacRate = totalVacRate;

colors = [
    0, 18, 25;
    0, 96, 115;
    9, 147, 150;
    145, 211, 192;
    235, 215, 165;
    238, 155, 0;
    204, 102, 2;
    188, 62, 3;
    174, 32, 18;   
    155, 34, 39
] / 255;

fig = figure;
set(fig, 'Units', 'normalized', 'OuterPosition', [0 0 1 1]);

tiledlayout(2, 3, 'TileSpacing', 'Compact');

ageGroups = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};

timeRange = T.Date(1780):T.Date(1840);  
timeDays = linspace(0.5, length(timeRange) - 0.5, length(timeRange)); 
optimumType = 1;

for ageIdx = 1:n
    nexttile;
    hold on;

    adjustedTotalVacNum = totalVacNum;
    params.fai = epiVacNum / day ./ population;
    
    pre27VacNumAdjusted = pre27VacNum;
    pre10VacNumAdjusted = pre10VacNum;

    Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
    S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
    params.initialStates(1:n) = S0;
    params.initialStates(5*n+1:6*n) = Sv0;

    dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
    [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

    casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
    casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
%%% 
    yPredicted = params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n); 
    yPredictedForI = params.p * params.omega * xPredicted(:, n+1:2*n);
    yPredictedForIV = params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n);
    yAgePredictedForI = trapz(tt, yPredictedForI);
    yAgePredictedForIV = trapz(tt, yPredictedForIV);
    
    avr.HospNumber = sum(yAgePredictedForI .* eco.HospRate + yAgePredictedForIV .* eco.HospRateForIV);
    avr.DeathNumber = sum(yAgePredictedForI .* eco.DeathRate + yAgePredictedForIV .* eco.DeathRateForIV);
    avr.Infections = sum(yAgePredictedForI + yAgePredictedForIV);
    avr.MediCost = sum(yAgePredictedForI .* eco.HospRate .* eco.MedCost + ...
    yAgePredictedForI .* (1 - eco.HospRate) .* eco.OutCost + ...
    yAgePredictedForIV .* eco.HospRateForIV .* eco.MedCostForIV + ...
    yAgePredictedForIV .* (1 - eco.HospRateForIV) .* eco.OutCostForIV);
    avr.VacNumber = sum(totalVacNum);
    avr.VacCost = sum(totalVacNum' .* eco.VaccineCost);

    avr.MediCostCi = [6.9824   10.5670]*1e6; %%%%%% 改参数需要更新
    avr.HospNumberCi = [190.0686  266.9001]; 
    avr.DeathNumberCi = [0.3313    1.0047]*1e3; 
%%%
    [resultTable, barTable] = optimumResultTable(resultTable, ageIdx, totalVacRate(ageIdx), ...
                                    adjustedTotalVacNum, ...
                                    casesPredictedInterp, population, ...
                                    eco, params, avr, optimumType, xPredicted, tt, barTable);
%%%
    plot(timeRange, casesPredictedInterp, 'LineWidth', 1.5, 'DisplayName', ...
         ['VR = ' num2str(round(initialVacRate(ageIdx) * 100, 2)) '%'], ...
         'Color', colors(1, :));
    drawnow;
    vacRateAdjustments = adjustedVacRates(adjustedVacRates > initialVacRate(ageIdx));
    adjustedColors = [];
    title(ageGroups{ageIdx})
    switch ageIdx
        case 2
            adjustedColors = colors([4, 7, 10], :);
        case 3
            adjustedColors = colors([2, 4, 6, 8, 10], :);
    end

    for i = 1:length(vacRateAdjustments)
        vacRateAdjusted = vacRateAdjustments(i);
        currentVacFactor = vacRateAdjusted / initialVacRate(ageIdx);
        pre27VacNumAdjusted(ageIdx) = pre27VacNum(ageIdx) * currentVacFactor;
        pre10VacNumAdjusted(ageIdx) = pre10VacNum(ageIdx) * currentVacFactor;

        adjustedTotalVacNum(ageIdx) = totalVacNum(ageIdx) * currentVacFactor;
        epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;
        params.fai = epiVacNumAdjusted / day ./ population;

        Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
        S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
        params.initialStates(1:n) = S0;
        params.initialStates(5*n+1:6*n) = Sv0;

        dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
        [tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

        casesPredicted = sum(xPredicted(:, [(2*n+1):3*n, (7*n+1):8*n]),2) / 1000;
        casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
        [resultTable, barTable] = optimumResultTable(resultTable, ageIdx, vacRateAdjusted, ...
                                        adjustedTotalVacNum, ...
                                        casesPredictedInterp, population, ...
                                        eco, params, avr, optimumType, xPredicted, tt, barTable);

        if ageIdx == 2
            if i <= size(adjustedColors, 1)
                colorToUse = adjustedColors(i, :);  
            else
                colorToUse = colors(mod(i, size(colors,1)) +1, :); 
            end
        elseif ageIdx == 3
            if i <= size(adjustedColors, 1)
                colorToUse = adjustedColors(i, :); 
            else
                colorToUse = colors(mod(i, size(colors,1)) +1, :); 
            end
        else
            colorToUse = colors(mod(i, size(colors,1)) +1, :);
        end

        plot(timeRange, casesPredictedInterp, 'LineWidth', 1, 'DisplayName', ...
             ['VR = ' num2str(round(vacRateAdjusted * 100, 2)) '%'], ...
             'Color', colorToUse);
        drawnow;
    end

    hold off;

    if ismember(ageIdx, [1, 4])
        ylabel('Infectious population','FontSize',10);
    end
    if ismember(ageIdx, [4, 5])
        xlabel('Date','FontSize',10);
    end

    xlim([timeRange(1), timeRange(end)]);
    % xtickformat('yyyy-MM');

    yticks = get(gca, 'YTick');
    yticklabels = arrayfun(@(y) sprintf('%dk', y), yticks, 'UniformOutput', false);
    set(gca, 'YTickLabel', yticklabels);


    lgd = legend('show', 'NumColumns', 1,'Box','off');
    lgd.FontSize = 6;
    legend show          

    % annotation('textbox', [annotationPositions(ageIdx, 1), annotationPositions(ageIdx, 2), 0.05, 0.05], ...
    %            'String', letters(ageIdx), 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
end

annotation('textbox', [0.07, 0.88, 0.05, 0.05], 'String', 'A', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.37, 0.88, 0.05, 0.05], 'String', 'B', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.67, 0.88, 0.05, 0.05], 'String', 'C', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.07, 0.43, 0.05, 0.05], 'String', 'D', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
annotation('textbox', [0.37, 0.43, 0.05, 0.05], 'String', 'E', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
% annotation('textbox', [0.29, 0.43, 0.05, 0.05], 'String', 'F', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');
% annotation('textbox', [0.51, 0.43, 0.05, 0.05], 'String', 'G', 'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none');

% exportgraphics(gcf, ['../Figures/' ...
%     'Optimization of 2024 vaccination.pdf'], 'Resolution', 300);


%% 疫苗优化 表格函数
function [resultTable, barTable]= optimumResultTable(resultTable, ageIdx, vacRateAdjusted, ...
                                         adjustedTotalVacNum,  ...
                                         casesPredicted, population, ...
                                         eco, params, avr, optimumType, xPredicted, tt, barTable)
    n = params.n;

    hospRate = eco.HospRate; 
    hospCi = eco.HospCI;     
    deathRate = eco.DeathRate;
    deathCi = eco.DeathCI;    
    medCost = eco.MedCost;   
    medCostCi = eco.MedCostCI;
    vaccineCost = eco.VaccineCost;
    vaccineCostCi = eco.VaccineCostCI;
    outCost = eco.OutCost;
    outCostCi = eco.OutCostCI;

    hospRateIV = eco.HospRateForIV; 
    hospCiIV = eco.HospCIForIV;     
    deathRateIV = eco.DeathRateForIV;
    deathCiIV = eco.DeathCIForIV;    
    medCostIV = eco.MedCostForIV;   
    medCostCiIV = eco.MedCostCIForIV;
    outCostIV = eco.OutCostForIV; 
    outCostCiIV = eco.OutCostCIForIV;

    % 第2列
    if optimumType == 1
    vaccineCount = adjustedTotalVacNum(ageIdx);
    vaccineCoverage = sprintf('%.2f%%', vacRateAdjusted * 100);
    % elseif optimumType == 2
    % vaccineCount = adjustedTotalVacNum;
    % vaccineCoverage = sprintf('%.2f%%', vacRateAdjusted * 100);
    else 
    vaccineCount = adjustedTotalVacNum;
    vaccineCoverage = sprintf('%.2f%%', vacRateAdjusted * 100);
    end
    % 第3列
    peakCases = max(casesPredicted) * 1000;
    peakCasesPercent = sprintf('%.2f‰', (peakCases / sum(population)) * 1000);

    % 第4列
    yPredictedForI = params.p * params.omega * xPredicted(:, n+1:2*n);
    yPredictedForIV = params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n);
    yAgePredictedForI = trapz(tt, yPredictedForI); 
    yAgePredictedForIV = trapz(tt, yPredictedForIV); 
    ageInfection = yAgePredictedForI + yAgePredictedForIV;
    totalInfections = sum(ageInfection); 
    CIR = totalInfections / sum(population);
    totalInfectionsPercent = sprintf('%.2f%%', (totalInfections / sum(population)) * 100);

    % 第5列
    hospCountsI = yAgePredictedForI .* hospRate; 
    hospCountsIV = yAgePredictedForIV .* hospRateIV; 
    totalHospCounts = sum(hospCountsI + hospCountsIV);
    hospCiTotal = sum(yAgePredictedForI' .* hospCi + yAgePredictedForIV' .* hospCiIV, 1); 
    hospRange = sprintf('[%.0f, %.0f]', hospCiTotal(1), hospCiTotal(2));

    % 第6列
    deathCountsI = yAgePredictedForI .* deathRate; 
    deathCountsIV = yAgePredictedForIV .* deathRateIV;
    totalDeathCounts = sum(deathCountsI + deathCountsIV);
    deathCiTotal = sum(yAgePredictedForI' .* deathCi + yAgePredictedForIV' .* deathCiIV, 1); 
    deathRange = sprintf('[%.0f, %.0f]', deathCiTotal(1), deathCiTotal(2));

    % 第7列
    medCosts = hospCountsI .* medCost + hospCountsIV .* medCostIV; 
    outCosts = (yAgePredictedForI - hospCountsI) .* outCost + (yAgePredictedForIV - hospCountsIV) .* outCostIV; 
    totalMedCosts = sum(medCosts + outCosts) / 1e6; 
    medCostCiTotal = sum(hospCountsI' .* medCostCi + hospCountsIV' .* medCostCiIV, 1) / 1e6; 
    outCostCiTotal = sum((yAgePredictedForI - hospCountsI)' .* outCostCi + (yAgePredictedForIV - hospCountsIV)' .* outCostCiIV, 1) / 1e6;
    medCostCiTotal = medCostCiTotal + outCostCiTotal;
    medCostRange = sprintf('[%.1f, %.1f]', medCostCiTotal(1), medCostCiTotal(2));

    % 第8列
    vaccineCosts = adjustedTotalVacNum .* vaccineCost'; 
    totalVaccineCosts = sum(vaccineCosts) / 1e6; 
    vaccineCostCiTotal = sum(adjustedTotalVacNum .* vaccineCostCi, 1) / 1e6; 
    vaccineCostRange = sprintf('[%.1f, %.1f]', vaccineCostCiTotal(1), vaccineCostCiTotal(2));

    % 第9-11列
    % vaccineDiff = sum(adjustedTotalVacNum) - avr.VacNumber; 
    % vaccineCostDiff = sum(vaccineCosts) - avr.VacCost;
    if optimumType == 1
    vaccineDiff = avr.VacNumber - sum(adjustedTotalVacNum); 
    vaccineCostDiff = avr.VacCost - sum(vaccineCosts);

    avgHospReduction = vaccineDiff / (totalHospCounts - avr.HospNumber); 
    avgHospReductionCi = vaccineDiff ./ (hospCiTotal - avr.HospNumberCi);
    avgHospReductionRange = sprintf('[%.0f, %.0f]', avgHospReductionCi(2), avgHospReductionCi(1));

    avgDeathReduction = vaccineDiff / (totalDeathCounts - avr.DeathNumber); 
    avgDeathReductionCi = vaccineDiff ./ (deathCiTotal - avr.DeathNumberCi);
    avgDeathReductionRange = sprintf('[%.0f, %.0f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgInfsReduction = vaccineDiff / (totalInfections - avr.Infections); 
    RRR = (avr.Infections - totalInfections) / avr.Infections * 100;
    
    % avgInfsReductionCi = vaccineDiff ./ (deathCiTotal - avr.Infections);
    % avgInfsReductionRange = sprintf('[%.2f, %.2f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgCostReduction = vaccineCostDiff / (totalMedCosts *1e6 - avr.MediCost); 
    
    avgCostReductionCi = vaccineCostDiff ./ (medCostCiTotal *1e6 - avr.MediCostCi);
    avgCostReductionRange = sprintf('[%.2f, %.2f]', avgCostReductionCi(2), avgCostReductionCi(1));

    else 
    vaccineDiff = 0; 

    avgHospReduction = vaccineDiff / (totalHospCounts - avr.HospNumber) *1e4; 
    avgHospReductionCi = vaccineDiff ./ (hospCiTotal - avr.HospNumberCi)*1e4;
    avgHospReductionRange = sprintf('[%.0f, %.0f]', avgHospReductionCi(2), avgHospReductionCi(1));

    avgDeathReduction = vaccineDiff / (totalDeathCounts - avr.DeathNumber)*1e4;
    avgDeathReductionCi = vaccineDiff ./ (deathCiTotal - avr.DeathNumberCi)*1e4;
    avgDeathReductionRange = sprintf('[%.0f, %.0f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgInfsReduction = vaccineDiff / (totalInfections - avr.Infections) *1e6; 
    RRR = (avr.Infections - totalInfections) / avr.Infections * 100;
    % 减少 1e6 个感染病例所需要的疫苗剂数
    % avgInfsReductionCi = vaccineDiff ./ (deathCiTotal - avr.Infections);
    % avgInfsReductionRange = sprintf('[%.2f, %.2f]', avgDeathReductionCi(2), avgDeathReductionCi(1));

    avgCostReduction = vaccineDiff / (totalMedCosts *1e6 - avr.MediCost) *1e6;
    %每节省 1e6 单位医疗费用所需增加的疫苗费用
    avgCostReductionCi = vaccineDiff ./ (medCostCiTotal *1e6 - avr.MediCostCi) .*1e6;
    avgCostReductionRange = sprintf('[%.2f, %.2f]', avgCostReductionCi(2), avgCostReductionCi(1));

    end


if optimumType == 1
    newRow = { ...
        eco.agegroup{ageIdx}, ...
        sprintf('%s (%.0f)', vaccineCoverage, vaccineCount), ...
        sprintf('%.0f (%s)', peakCases, peakCasesPercent), ...
        sprintf('%.0f (%s)', totalInfections, totalInfectionsPercent), ...
        sprintf('%.0f %s', totalHospCounts, hospRange), ...
        sprintf('%.0f %s', totalDeathCounts, deathRange), ...
        sprintf('%.1f %s', totalMedCosts, medCostRange), ...
        sprintf('%.1f %s', totalVaccineCosts, vaccineCostRange), ...
        sprintf('%.0f %s', avgHospReduction, avgHospReductionRange), ...
        sprintf('%.0f %s', avgDeathReduction, avgDeathReductionRange), ...
        sprintf('%.2f %s', avgCostReduction, avgCostReductionRange) ...
        sprintf('%.2f', avgInfsReduction)};
     resultTable = [resultTable; newRow];
     barTable = [barTable; {eco.agegroup{ageIdx}, vacRateAdjusted, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), CIR, RRR}];
elseif optimumType == 2
        newRow = { ...
        'Week', ... 
        sprintf('%.0f (%s)', vaccineCount, vaccineCoverage), ...
        sprintf('%.0f (%s)', peakCases, peakCasesPercent), ...
        sprintf('%.0f (%s)', totalInfections, totalInfectionsPercent), ...
        sprintf('%.0f %s', totalHospCounts, hospRange), ...
        sprintf('%.0f %s', totalDeathCounts, deathRange), ...
        sprintf('%.2f %s', totalMedCosts, medCostRange), ...
        sprintf('%.1f %s', totalVaccineCosts, vaccineCostRange), ...
        sprintf('%.0f %s', avgHospReduction, avgHospReductionRange), ...
        sprintf('%.2f %s', avgDeathReduction, avgDeathReductionRange), ...
        sprintf('%.2f %s', avgCostReduction, avgCostReductionRange) ...
        sprintf('%.2f', avgInfsReduction)};
     resultTable = [resultTable; newRow];
     barTable = [barTable; {'Earlier Timing', ageIdx, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), CIR, RRR}];
elseif optimumType == 3
        newRow = { ...
        'Speed', ... 
        sprintf('%.2f (%s)', vaccineCount, vaccineCoverage), ...
        sprintf('%.0f (%s)', peakCases, peakCasesPercent), ...
        sprintf('%.0f (%s)', totalInfections, totalInfectionsPercent), ...
        sprintf('%.0f %s', totalHospCounts, hospRange), ...
        sprintf('%.0f %s', totalDeathCounts, deathRange), ...
        sprintf('%.2f %s', totalMedCosts, medCostRange), ...
        sprintf('%.1f %s', totalVaccineCosts, vaccineCostRange), ...
        sprintf('%.0f %s', avgHospReduction, avgHospReductionRange), ...
        sprintf('%.2f %s', avgDeathReduction, avgDeathReductionRange), ...
        sprintf('%.2f %s', avgCostReduction, avgCostReductionRange) ...
        sprintf('%.2f', avgInfsReduction)};
     resultTable = [resultTable; newRow];
     barTable = [barTable; {'Accelerated Rate', ageIdx, ageInfection(1), ageInfection(2), ageInfection(3), ageInfection(4), ageInfection(5), CIR, RRR}];
end


end

%% 将表格保存为Excel文件
resultTable = movevars(resultTable, "HICER", "Before", "Deaths");
resultTable = movevars(resultTable, 10, "Before", 8);
resultTable = movevars(resultTable, "CIICER", "Before", "Hospitalizations");

resultTable.HICER(contains(resultTable.HICER,'NaN')) = {'NaN'};
resultTable.DICER(contains(resultTable.DICER,'NaN')) = {'NaN'};
resultTable.DMCICER(contains(resultTable.DMCICER,'0.00')) = {'NaN'};
delete('2024optimumTable.xlsx')
optimumTable = resultTable(contains(resultTable.AgeGroup,'age'), :);
writetable(optimumTable, '2024optimumTable.xlsx');


%%  分年龄组堆叠柱状图 Optimum

optimumType = unique(barTable.AgeGroup);
colors = [194, 171, 200;
          144, 37, 37;
          242, 187, 107;
          222, 120, 51;
          112, 130, 200] / 255;  % RGB颜色矩阵
blue_color = [106 155 203]/255;

for i = 1:length(optimumType)
    tempTable = barTable(strcmp(barTable.AgeGroup, optimumType{i}), :);

    % 数据预处理
    stackedData = tempTable{:, 3:7} / 1000; 
    sumData = sum(stackedData, 2);  

    figure('Position', [100 100 1000 500])

    % 左轴-堆叠条形图
    yyaxis left
    b = bar(stackedData, 'stacked'); 

    % 设置条形颜色
    for j = 1:numel(b)
        b(j).FaceColor = colors(j,:);
        b(j).DisplayName = tempTable.Properties.VariableNames{j+2};
    end

    % 左轴格式设置
    ax = gca;
    ax.YAxis(1).Color = 'k';
    ax.YAxis(1).Limits = [0 max(sumData)*1.4];
    ax.YAxis(1).TickLabelFormat = '%.0fk';
    ylabel('Cumulative Infections','FontSize',8)

    % 添加柱顶标签（关键修复部分）
    labels = arrayfun(@(v) sprintf('%.2f%%', v*100), tempTable.CIR, 'UniformOutput', false); 
    text(1:length(sumData), sumData, labels,...  
        'HorizontalAlignment', 'center',...
        'VerticalAlignment', 'bottom',...
        'FontSize', 9,...
        'Margin', 0.5); 

    % 右轴-折线图
    yyaxis right
    p = plot(tempTable.RRR, '-o',... 
           'Color', [blue_color 0.6],...
           'MarkerSize', 6,...
           'LineWidth', 1.5,...
           'DisplayName', 'RRR');

    % 右轴格式设置
    ax.YAxis(2).Color = blue_color;
    ax.YAxis(2).Limits = [0 100];
    ax.YAxis(2).TickLabelFormat = '%.0f%%';
    ylabel('Relative Risk Reduction','FontSize',8)

    xticks(1:height(tempTable))
    xLabels = tempTable.VR * 100;
    xticklabels(arrayfun(@(v) sprintf('%.2f%%', v), xLabels, 'UniformOutput', false))
    title(optimumType{i})
    xlabel('Vaccination Coverage Rate',FontSize = 8)
    xlim([0.5 height(tempTable)+0.5])

    % 图例
    % legend('Location', 'northeast','Box','off','FontSize',8) 
    exportgraphics(gcf, sprintf('../Figures/Optimum/2024%s.pdf', optimumType{i}),...
        'Resolution', 300,...
        'ContentType', 'vector');
end

%% 总防控效果图 2024
estimatedA = readmatrix('estimatedA3.xlsx');
estimatedB = readmatrix('estimatedB3.xlsx');

load('VaccinationTable.mat')
load('processedTable.mat');
% %%
n = 5;
params.tSpan = [0, 60] + 0.5;
params.k  = 0.50;
params.omega  = 0.53;
params.omega1  = 0.83;
params.p = 0.667;
params.gamma  = 0.31;
params.gamma1  = 0.25;
params.f = 0.1;
params.n = 5;
% 1780:1840
% 疫苗效果参数
params.VEI = 0.4; % 20-40
params.VES = 0.4; % 30-40
params.VEP = 0.67; % 14-67 

aValues = linspace(0.01, 1.3, 101);
A = aValues(12) * ones(n);

B =  0 * ones(n);
C = [A(:); B(:)];

% 2023-10-22(1373),2023-12-19(1431),   
% 2024-02-13(1487) T 
% 2024-12-02(1780)  2025-01-31(1840) 

E0 = T{1779,2:6}'/params.p / params.omega * (1 - params.VES);
I0 = T{1780,2:6}' * (1 - params.VES);
A0 = [0, 0, 0, 0, 0]';
R0 = [0, 0, 0, 0, 0]';

pre27VacNum = sum(VT{1624:1707-1 - 1/params.f, 2:6})';
pre10VacNum = sum(VT{1707-1/params.f:1706, 2:6})';
% 1300:1450 ,2023-9-15,2024-2-13 VT
% 1337 ,    2023-10-22

% 1624:1765, '2024-09-10' '2025-01-31'
% 1707, '2024-12-02'
population = [103.26, 129.98, 72.28, 1413.68, 465.1]' * 1e4;
totalVacNum = sum(VT{1624:1765, 2:6})';
totalVacRate = totalVacNum ./ population;
epiVacNum = totalVacNum - pre27VacNum - pre10VacNum * 0.5;
day = days(VT.Date(1765) - VT.Date(1707)) + 1 ;
params.fai = epiVacNum / day ./ population;% 流行季节平均每日疫苗接种率

Sv0 = pre27VacNum  + pre10VacNum * 0.5;
Ev0 = T{1779,2:6}'/params.p / params.omega * params.VES;
Iv0 = T{1780,2:6}'* params.VES;
Av0 = [0, 0, 0, 0, 0]';
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates = [S0; E0; I0; A0; R0; Sv0; Ev0; Iv0; Av0];

%%%%%%%%%%%
initialTotalVacNum = sum(totalVacNum);
ageGroups = {'age0-5', 'age6-12', 'age13-18', 'age19-59', 'age60+'};
timeRange = T.Date(1780):T.Date(1840);
timeDays = linspace(0.5, length(timeRange) - 0.5, length(timeRange));

figure('Position', [100, 50, 1200, 1000])

%%%%%%%%%%%%%%%%%%%%%%%%%%%   实际情况
dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

casesPredicted = sum(params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n), 2) / 1000;

casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
plot(timeRange, casesPredictedInterp, 'LineWidth', 1,'Color','k', ...
    'DisplayName','Actual Epidemic');

hold on


%%%%%%%%%%%%%%%%%%%%%%  模拟无干预状态
vacRateFactor = [0.0175856825106477; 0.0224182422708550; 0.0625824161037703];

pre27VacNumAdjusted = pre27VacNum;
pre10VacNumAdjusted = pre10VacNum;
adjustedTotalVacNum = totalVacNum;

pre27VacNumAdjusted([2, 3, 5]) = pre27VacNum([2, 3, 5]) .* vacRateFactor;
pre10VacNumAdjusted([2, 3, 5]) = pre10VacNum([2, 3, 5]) .* vacRateFactor;
adjustedTotalVacNum([2, 3, 5]) = totalVacNum([2, 3, 5]) .* vacRateFactor;

epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;
params.fai = epiVacNumAdjusted / day ./ population;

Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;

dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

casesPredicted = sum(params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n), 2) / 1000;
casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');
% plot(timeRange, casesPredictedInterp, 'LineWidth', 1,'LineStyle','--');
% plot(timeRange, casesPredictedInterp, 'LineWidth', 1,'LineStyle','--', ...
%     'DisplayName', ['SVR = ' num2str(0.01 * 100, '%.0f') '%']);
plot(timeRange, casesPredictedInterp, 'LineWidth', 1.3,'LineStyle','--', 'color','r', ...
    'DisplayName', 'Without Strategy');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     优化年龄组0-5岁至VR 到50%

initialVacRate = totalVacRate;
adjustedTotalVacNum = totalVacNum;
params.fai = epiVacNum / day ./ population;
pre27VacNumAdjusted = pre27VacNum;
pre10VacNumAdjusted = pre10VacNum;
Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;

vacRateAdjusted = 0.5;
currentVacFactor = vacRateAdjusted / initialVacRate(1);
pre27VacNumAdjusted(1) = pre27VacNum(1) * currentVacFactor;
pre10VacNumAdjusted(1) = pre10VacNum(1) * currentVacFactor;

adjustedTotalVacNum(1) = totalVacNum(1) * currentVacFactor;
epiVacNumAdjusted = adjustedTotalVacNum - pre27VacNumAdjusted - pre10VacNumAdjusted * 0.5;
params.fai = epiVacNumAdjusted / day ./ population;

Sv0 = pre27VacNumAdjusted  + pre10VacNumAdjusted * 0.5;
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates(1:n) = S0;
params.initialStates(5*n+1:6*n) = Sv0;

dxdt = @(t, x) computeDerivative(estimatedA, estimatedB, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);

casesPredicted = sum(params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n), 2) / 1000;
casesPredictedInterp = interp1(tt, casesPredicted, timeDays, 'linear', 'extrap');

plot(timeRange, casesPredictedInterp, 'LineWidth', 1.3,'LineStyle','-.', 'color','b', ...
    'DisplayName', 'Optimized Age 0-5');

legend show
xlim([timeRange(1), timeRange(end)]);
drawnow;
% xtickformat('yyyy-MM');

title('2024 Winter Influenza Epidemic')
yticks = get(gca, 'YTick');
yticklabels = arrayfun(@(y) sprintf('%dk', y), yticks, 'UniformOutput', false);
set(gca, 'YTickLabel', yticklabels);
ylabel('Daily Cases','FontSize',10)
xlabel('Date','FontSize',10)

% exportgraphics(gcf, '../Figures/2024冬天总防控效果对比图.pdf', 'Resolution', 300);
