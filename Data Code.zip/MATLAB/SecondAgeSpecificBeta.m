% close all; clear; clc;
close all;
n = 5;  % number of subgroups 

load('VaccinationTable.mat')
load('processedTable.mat')
params.tSpan = [0, 56] + 0.5;
params.k  = 0.50;
params.omega  = 0.53;
params.omega1  = 0.83;
params.p = 0.667;
params.gamma  = 0.31;
params.gamma1  = 0.25;
params.f = 0.1;
params.n = 5;

% 疫苗效果参数
params.VEI = 0.4; % 20-40
params.VES = 0.4; % 30-40
params.VEP = 0.67; % 14-67 

aValues = linspace(0.01, 1.3, 101);  
A = aValues(18) * ones(n);

B =  0 * ones(n);
C = [A(:); B(:)];

pre27VacNum = sum(VT{1300:1337-1 - 1/params.f, 2:6})';
pre10VacNum = sum(VT{1337-1/params.f:1336, 2:6})';
% 1300:1450 ,2023-9-15,2024-2-13
% 1337 ,    2023-10-22
population = [103.26, 129.98, 72.28, 1413.68, 465.1]' * 1e4;
totalVacNum = sum(VT{1300:1450, 2:6})';
totalVacRate = totalVacNum ./ population;
epiVacNum = totalVacNum - pre27VacNum - pre10VacNum * 0.5;
day = days(VT.Date(1450) - VT.Date(1337)) +1 ;
params.fai = epiVacNum / day ./ population;% 流行季节平均每日疫苗接种率
% 2023-10-22(1373),2023-12-19(1431),2024-02-13(1487) 

load("secInitial.mat")
params.initialStates = secInitial';



%% 求解最优化问题

observedIncidence = T{1431:1487,2:6};
objectiveFunction = @(unknowns) computeParameterLikelihood(reshape(unknowns(1:n^2),n,n), reshape(unknowns(1+n^2:end),n,n),params, observedIncidence);

% options = optimoptions('fmincon', 'MaxFunctionEvaluations', 1e5, 'MaxIterations', 1e3, 'PlotFcn', 'optimplotfval'); 
options = optimoptions('fmincon', 'MaxFunctionEvaluations', 1e5, 'MaxIterations', 1e3); 
[D, finalErrorValue] = fmincon(objectiveFunction, C(:), [], [], [], [], ...
    [0*ones(n^2,1), -2*pi*ones(n^2,1)], [1.3*ones(n^2,1); 2*pi*ones(n^2,1)], [], options);
disp(finalErrorValue)
clear options;

estimatedA = reshape(D(1:n^2), n, n);
estimatedB = reshape(D(1+n^2:end), n, n);

% clear options;
% 在初始的Beta下模拟得到模型预测值
dxdt = @(t,x) computeDerivative(estimatedA, estimatedB, params, t, x);
% [tt, xPredicted] = ode23s(dxdt, params.tSpan, params.initialStates);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
yPredicted = params.p * params.omega * xPredicted(:, n+1:2*n) ...
    + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n+1:7*n); % omega * E

figure; heatmap(estimatedA)
figure; heatmap(estimatedB)
fig = figure;
fig.Position = [248.2,291.4,800.4,584];
tiledlayout(2,1)
ax1 = nexttile; plot(T{1431:1487,2:6});
legend('age1','age2','age3','age4','age5')
ax2 = nexttile; plot(tt, yPredicted);
legend('age1','age2','age3','age4','age5')
ax2.YLim = ax1.YLim;


% figure; plot(tt, xPredicted)
%%
writematrix(estimatedA,'totalSimulate/estimatedA2.xlsx');
writematrix(estimatedB, 'totalSimulate/estimatedB2.xlsx');
writematrix(estimatedA, 'estimatedA2.xlsx');
writematrix(estimatedB, 'estimatedB2.xlsx');

