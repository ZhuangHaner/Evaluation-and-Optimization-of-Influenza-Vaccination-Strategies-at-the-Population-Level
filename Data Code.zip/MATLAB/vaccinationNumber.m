clear; close all ;clc;
opts = detectImportOptions("result.xlsx");
opts.Sheet = "result";
opts.DataRange = "A2:E53769";
opts.VariableNames = ["VarName1", "virus", "VACCINATION_DATE", "age_group", "total"];
opts.VariableTypes = ["double", "categorical", "datetime", "string", "double"];
opts = setvaropts(opts, ["virus", "age_group"], "EmptyFieldRule", "auto");

result = readtable("result.xlsx", opts);
result = removevars(result, "VarName1");
result = result(~strcmp(result.age_group, 'NA'), :);

% %%
data = result;
data.age_group = string(data.age_group);
ageGroup = unique(data.age_group);

for i = 1:length(ageGroup)
    tempRow = data.age_group == ageGroup{i};
    eval(sprintf('Table%d = data(tempRow, :);', i));
end

table_list = {Table1, Table2, Table3, Table4, Table5, Table6};
summed_tables = cell(1, 6);

for i = 1:6
    current_table = table_list{i};
    summed_table = varfun(@sum, current_table, 'InputVariables', 'total', ...
                          'GroupingVariables', {'VACCINATION_DATE', 'age_group'});
    summed_table.Properties.VariableNames{'sum_total'} = 'total';
    summed_tables{i} = summed_table;
end

Table1 = summed_tables{1};
Table2 = summed_tables{2};
Table3 = summed_tables{3};
Table4 = summed_tables{4};
Table5 = summed_tables{5};
Table6 = summed_tables{6};

T1 = table(Table1.VACCINATION_DATE, Table1.total, 'VariableNames', {'Date', 'age0_5'});
T2 = table(Table2.VACCINATION_DATE, Table2.total, 'VariableNames', {'Date', 'age13_18'});
T3 = table(Table3.VACCINATION_DATE, Table3.total, 'VariableNames', {'Date', 'age19_59'});
T4 = table(Table4.VACCINATION_DATE, Table4.total, 'VariableNames', {'Date', 'age6_12'});
T5 = table(Table5.VACCINATION_DATE, Table5.total, 'VariableNames', {'Date', 'age60_79'});
T6 = table(Table6.VACCINATION_DATE, Table6.total, 'VariableNames', {'Date', 'age80_plus'});

VT = outerjoin(T1, T2, 'MergeKeys', true);
VT = outerjoin(VT, T3, 'MergeKeys', true);
VT = outerjoin(VT, T4, 'MergeKeys', true);
VT = outerjoin(VT, T5, 'MergeKeys', true);
VT = outerjoin(VT, T6, 'MergeKeys', true);
VT = VT(:, [1, 2, 5, 3, 4, 6:end]);
VT{:,2:7}(isnan(VT{:,2:7})) = 0;


% %%
VT{:, 6} = VT{:, 6} + VT{:, 7};
VT(:, 7) = [];
VT.Properties.VariableNames{6} = 'age60+';


opts = spreadsheetImportOptions("NumVariables", 5);

% 指定工作表和范围
opts.Sheet = "疫苗";
opts.DataRange = "A2:E16381";

% 指定列名称和类型
opts.VariableNames = ["VarName1", "virus", "VACCINATION_DATE", "age_group", "total"];
opts.VariableTypes = ["double", "categorical", "datetime", "categorical", "double"];

% 指定变量属性
opts = setvaropts(opts, ["virus", "age_group"], "EmptyFieldRule", "auto");

% 导入数据
result = readtable("C:\Users\Administrator\Desktop\0 北京市流感项目\Codes\疫苗 NEW.xlsx", opts, "UseExcel", false);

% result = readtable("疫苗 NEW.xlsx", opts);
result = removevars(result, "VarName1");
% result = result(~strcmp(result.age_group, 'NA'), :);

% %%
data = result;
data.age_group = string(data.age_group);
ageGroup = unique(data.age_group);

for i = 1:length(ageGroup)
    tempRow = data.age_group == ageGroup{i};
    eval(sprintf('Table%d = data(tempRow, :);', i));
end

table_list = {Table1, Table2, Table3, Table4, Table5, Table6};
summed_tables = cell(1, 6);

for i = 1:6
    current_table = table_list{i};
    summed_table = varfun(@sum, current_table, 'InputVariables', 'total', ...
                          'GroupingVariables', {'VACCINATION_DATE', 'age_group'});
    summed_table.Properties.VariableNames{'sum_total'} = 'total';
    summed_tables{i} = summed_table;
end

Table1 = summed_tables{1};
Table2 = summed_tables{2};
Table3 = summed_tables{3};
Table4 = summed_tables{4};
Table5 = summed_tables{5};
Table6 = summed_tables{6};

T1 = table(Table1.VACCINATION_DATE, Table1.total, 'VariableNames', {'Date', 'age0_5'});
T2 = table(Table2.VACCINATION_DATE, Table2.total, 'VariableNames', {'Date', 'age13_18'});
T3 = table(Table3.VACCINATION_DATE, Table3.total, 'VariableNames', {'Date', 'age19_59'});
T4 = table(Table4.VACCINATION_DATE, Table4.total, 'VariableNames', {'Date', 'age6_12'});
T5 = table(Table5.VACCINATION_DATE, Table5.total, 'VariableNames', {'Date', 'age60_79'});
T6 = table(Table6.VACCINATION_DATE, Table6.total, 'VariableNames', {'Date', 'age80_plus'});

VT2 = outerjoin(T1, T2, 'MergeKeys', true);
VT2 = outerjoin(VT2, T3, 'MergeKeys', true);
VT2 = outerjoin(VT2, T4, 'MergeKeys', true);
VT2 = outerjoin(VT2, T5, 'MergeKeys', true);
VT2 = outerjoin(VT2, T6, 'MergeKeys', true);
VT2 = VT2(:, [1, 2, 5, 3, 4, 6:end]);
VT2{:,2:7}(isnan(VT2{:,2:7})) = 0;


% %%
VT2{:, 6} = VT2{:, 6} + VT2{:, 7};
VT2(:, 7) = [];
VT2.Properties.VariableNames{6} = 'age60+';

VT = [VT; VT2];
VT(1557:1605, :) = [];

% %%
save('VaccinationTable.mat', 'VT');

