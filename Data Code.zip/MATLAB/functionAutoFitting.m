clear;close all;clc
n = 5;
aValues = linspace(0.01, 1.3, 135);  
results = zeros(length(aValues), 2); 
load('VaccinationTable.mat')
load('processedTable.mat')

for i = 100:length(aValues)
    clear finalErrorValue ;
    a = aValues(i);
    A = a * ones(n); 
    % assignin('base', 'A', A); 
    % run('WinterFlu2024.m');  
    error = autofit(A,T,VT);
    results(i, :) = [a, error];
    fprintf('a = %.2f, Final Error Value = %.1f\n', a, error);

end




function error = autofit(A,T,VT)
close all;
n = 5;  % number of subgroups
% %%
params.tSpan = [0, 60] + 0.5;
params.k  = 0.50;
params.omega  = 0.53;
params.omega1  = 0.83;
params.p = 0.667;
params.gamma  = 0.31;
params.gamma1  = 0.25;
params.f = 0.1;
params.n = 5;
% 1780:1840
% 疫苗效果参数
params.VEI = 0.4; % 20-40
params.VES = 0.4; % 30-40
params.VEP = 0.67; % 14-67

% aValues = linspace(0.01, 1.3, 101);
% A = aValues(12) * ones(n);

B =  0 * ones(n);
C = [A(:); B(:)];

% 2023-10-22(1373),2023-12-19(1431),
% 2024-02-13(1487) T
% 2024-12-02(1780)  2025-01-31(1840)

E0 = T{1779,2:6}'/params.p / params.omega * (1 - params.VES);
I0 = T{1780,2:6}' * (1 - params.VES);
A0 = [0, 0, 0, 0, 0]';
R0 = [0, 0, 0, 0, 0]';

pre27VacNum = sum(VT{1624:1707-1 - 1/params.f, 2:6})';
pre10VacNum = sum(VT{1707-1/params.f:1706, 2:6})';
% 1300:1450 ,2023-9-15,2024-2-13 VT
% 1337 ,    2023-10-22

% 1624:1765, '2024-09-10' '2025-01-31'
% 1707, '2024-12-02'
population = [103.26, 129.98, 72.28, 1413.68, 465.1]' * 1e4;
totalVacNum = sum(VT{1624:1765, 2:6})';
totalVacRate = totalVacNum ./ population;
epiVacNum = totalVacNum - pre27VacNum - pre10VacNum * 0.5;
day = days(VT.Date(1765) - VT.Date(1707)) + 1 ;
params.fai = epiVacNum / day ./ population;% 流行季节平均每日疫苗接种率

Sv0 = pre27VacNum  + pre10VacNum * 0.5;
Ev0 = T{1779,2:6}'/params.p / params.omega * params.VES;
Iv0 = T{1780,2:6}'* params.VES;
Av0 = [0, 0, 0, 0, 0]';
S0 = population - E0 - I0 - A0 - Sv0 - Ev0 - Av0 - Iv0;
params.initialStates = [S0; E0; I0; A0; R0; Sv0; Ev0; Iv0; Av0];

% %% 求解最优化问题


observedIncidence = T{1780:1840,2:6};
objectiveFunction = @(unknowns) computeParameterLikelihood(reshape(unknowns(1:n^2),n,n), reshape(unknowns(1+n^2:end),n,n),params, observedIncidence);

% options = optimoptions('fmincon', 'MaxFunctionEvaluations', 1e5, 'MaxIterations', 1e3, 'PlotFcn', 'optimplotfval');
options = optimoptions('fmincon', 'MaxFunctionEvaluations', 1e5, 'MaxIterations', 1e3);
[D, finalErrorValue] = fmincon(objectiveFunction, C(:), [], [], [], [], ...
    [0*ones(n^2,1), -2*pi*ones(n^2,1)], [1.3*ones(n^2,1); 2*pi*ones(n^2,1)], [], options);
% disp(finalErrorValue)
error = finalErrorValue;
clear options;
    


end