function dxdt = computeDerivative(Amplitude, Phase1, params, t, x)

    n = numel(x) / 9; % number of age groups
    idx = 1:n;

    S = x(0*n + idx);
    E = x(1*n + idx);
    I = x(2*n + idx);
    A = x(3*n + idx);
    R = x(4*n + idx);
    Sv = x(5*n + idx);
    Ev = x(6*n + idx);
    Iv = x(7*n + idx);
    Av = x(8*n + idx);

    N = S + E + I + A + R + Sv + Ev + Iv + Av;
    Betat = Amplitude .* max(0, sin(2 * pi / 65* t + Phase1));  
    
    interactionTerm = Betat' * (I + params.k * A)./N;  
    interactionTermVE = (1 - params.VEI) * Betat' * (Iv + params.k * Av)./N;  

    dSdt = - params.f * params.fai .* S - interactionTerm .* (1 - params.f * params.fai) .* S ...
        - (1 - params.f * params.fai) .* S .* interactionTermVE;
    dEdt = interactionTerm .* (1 - params.f * params.fai) .* S + (1 - params.f * params.fai) .* S .* interactionTermVE ...
        - params.p * params.omega * E  - (1 - params.p) * params.omega1 * E ;
    dIdt = params.p * params.omega * E - params.gamma * I;
    dAdt = (1 - params.p) * params.omega1 * E - params.gamma1 * A;
    dRdt = params.gamma1 * A + params.gamma * I + params.gamma1 * Av + params.gamma * Iv ;
    dSvdt =  params.f * params.fai .* S - interactionTerm * (1 - params.VES) .* Sv  ...
        - (1 - params.VES) * Sv .* interactionTermVE ; 
    dEvdt = interactionTerm * (1 - params.VES) .* Sv + (1 - params.VES) * Sv .* interactionTermVE ...
        - params.p * (1 - params.VEP) * params.omega * Ev - (1 - (params.p * (1-params.VEP))) * params.omega1 * Ev;
    dIvdt = params.p * (1 - params.VEP) * params.omega * Ev - params.gamma * Iv;
    dAvdt = (1 - (params.p * (1-params.VEP))) * params.omega1 * Ev - params.gamma1 * Av;
    
    dxdt = [dSdt; dEdt; dIdt; dAdt; dRdt; dSvdt; dEvdt; dIvdt; dAvdt];
end

