function residue = computeParameterLikelihood(Amplitude, Phase, params, observedIncidence)

n = size(Amplitude, 1);
idx = 1:n;

dxdt = @(t,x) computeDerivative(Amplitude, Phase, params, t, x);
[tt, xPredicted] = ode45(dxdt, params.tSpan, params.initialStates);
newCases = params.p * params.omega * xPredicted(:, 1*n + idx) + params.p * (1 - params.VEP) * params.omega * xPredicted(:, 6*n + idx);
yPredicted = interp1(tt, newCases, ((0.5:params.tSpan(2))), "linear", 0); 
yObserved = observedIncidence;

residue = norm(yObserved - yPredicted, 'fro');
end

